ParticleShowcase — Paper 1.21.11
Команды: /pshow list | /pshow <эффект> | /pshow all | /pshow stop
Права: particleshowcase.use (по умолчанию op)
Эффекты: basics, tunnel, tornado, geosphere, ripples, lightning, lissajous, halo, wave, beam
Смотреть в сторону, куда хотите эффект: tunnel, lightning, beam берут направление взгляда.
