package ru.showcase;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class ParticleShowcase extends JavaPlugin implements TabExecutor {

    private final Map<UUID, List<BukkitTask>> active = new HashMap<>();

    @Override
    public void onEnable() {
        PluginCommand c = getCommand("pshow");
        if (c != null) {
            c.setExecutor(this);
            c.setTabCompleter(this);
        }
    }

    @Override
    public void onDisable() {
        for (List<BukkitTask> l : active.values()) {
            for (BukkitTask t : l) t.cancel();
        }
        active.clear();
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!(s instanceof Player p)) {
            s.sendMessage("Команда только для игроков.");
            return true;
        }
        if (a.length == 0 || a[0].equalsIgnoreCase("list")) {
            s.sendMessage("Эффекты: " + String.join(", ", Effects.ALL.keySet()) + " | all (все по очереди) | stop");
            return true;
        }
        String n = a[0].toLowerCase(Locale.ROOT);
        if (n.equals("stop")) {
            stop(p);
            p.sendMessage("Остановлено.");
            return true;
        }
        if (n.equals("all")) {
            stop(p);
            int at = 0;
            for (String k : Effects.ALL.keySet()) {
                final String key = k;
                addTask(p, Bukkit.getScheduler().runTaskLater(this, () -> launch(p, key), at));
                at += Effects.LEN.get(k) + 40;
            }
            p.sendMessage("Запущены все эффекты по очереди (~" + (at / 20) + " сек). Остановить: /pshow stop");
            return true;
        }
        if (!Effects.ALL.containsKey(n)) {
            p.sendMessage("Нет такого эффекта. /pshow list");
            return true;
        }
        launch(p, n);
        return true;
    }

    private void launch(Player p, String key) {
        if (!p.isOnline()) return;
        addTask(p, Effects.ALL.get(key).start(this, p));
    }

    private void addTask(Player p, BukkitTask t) {
        List<BukkitTask> l = active.computeIfAbsent(p.getUniqueId(), k -> new ArrayList<>());
        l.removeIf(BukkitTask::isCancelled);
        l.add(t);
    }

    private void stop(Player p) {
        List<BukkitTask> l = active.remove(p.getUniqueId());
        if (l != null) {
            for (BukkitTask t : l) t.cancel();
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String alias, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            List<String> all = new ArrayList<>(Effects.ALL.keySet());
            all.add("all");
            all.add("stop");
            all.add("list");
            for (String x : all) {
                if (x.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(x);
            }
        }
        return out;
    }
}
