package ru.showcase;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

/** Все эффекты частиц. Каждый эффект = BukkitTask, который сам останавливается. */
final class Effects {

    private Effects() {}

    interface Starter {
        BukkitTask start(JavaPlugin pl, Player p);
    }

    static final Random R = new Random();
    static final Map<String, Starter> ALL = new LinkedHashMap<>();
    static final Map<String, Integer> LEN = new LinkedHashMap<>();

    static {
        reg("basics", 40, Effects::basics);        // команда /particle: огонь души, пламя, end_rod
        reg("tunnel", 100, Effects::tunnel);       // бирюзовые кольца-тоннель + светящаяся полоса
        reg("tornado", 120, Effects::tornado);     // розовый смерч-спираль
        reg("geosphere", 160, Effects::geosphere); // фиолетовая геосфера из линий + звёзды
        reg("ripples", 140, Effects::ripples);     // расходящиеся чёрные/фиолетовые кольца
        reg("lightning", 32, Effects::lightning);  // белая молния с ветвями
        reg("lissajous", 220, Effects::lissajous); // оранжевые восьмёрки/петли
        reg("halo", 180, Effects::halo);           // белые точечные кольца вокруг орбит + взрывы лучей
        reg("wave", 100, Effects::wave);           // красно-чёрная волна из dust
        reg("beam", 110, Effects::beam);           // фиолетовый электро-луч + многогранники
    }

    private static void reg(String n, int len, Starter s) {
        ALL.put(n, s);
        LEN.put(n, len);
    }

    // ---------------------------------------------------------------- helpers

    static BukkitTask run(JavaPlugin pl, int duration, IntConsumer body) {
        return new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                if (t >= duration) {
                    cancel();
                    return;
                }
                body.accept(t++);
            }
        }.runTaskTimer(pl, 0L, 1L);
    }

    static void dust(World w, Vector v, int r, int g, int b, float size) {
        w.spawnParticle(Particle.DUST, v.getX(), v.getY(), v.getZ(), 1, 0.0, 0.0, 0.0, 0.0,
                new Particle.DustOptions(Color.fromRGB(r, g, b), size));
    }

    static void fx(World w, Particle p, Vector v) {
        w.spawnParticle(p, v.getX(), v.getY(), v.getZ(), 1, 0.0, 0.0, 0.0, 0.0);
    }

    static Vector[] basis(Vector d) {
        Vector u = d.clone().crossProduct(new Vector(0, 1, 0));
        if (u.lengthSquared() < 1e-6) u = new Vector(1, 0, 0);
        u.normalize();
        Vector v = u.clone().crossProduct(d).normalize();
        return new Vector[]{u, v};
    }

    static Vector at(Vector c, Vector u, Vector v, double a, double r) {
        return c.clone()
                .add(u.clone().multiply(Math.cos(a) * r))
                .add(v.clone().multiply(Math.sin(a) * r));
    }

    static void line(Vector a, Vector b, double step, Consumer<Vector> out) {
        Vector dir = b.clone().subtract(a);
        double len = dir.length();
        if (len < 1e-6) return;
        dir.multiply(1.0 / len);
        for (double s = 0; s <= len; s += step) {
            out.accept(a.clone().add(dir.clone().multiply(s)));
        }
    }

    static Vector flat(Player p) {
        Vector f = p.getLocation().getDirection().setY(0);
        if (f.lengthSquared() < 1e-6) f = new Vector(0, 0, 1);
        return f.normalize();
    }

    static Vector rnd() {
        Vector v = new Vector(R.nextGaussian(), R.nextGaussian(), R.nextGaussian());
        if (v.lengthSquared() < 1e-6) return new Vector(0, 1, 0);
        return v.normalize();
    }

    // ---------------------------------------------------------------- 0:43 basics

    static BukkitTask basics(JavaPlugin pl, Player p) {
        World w = p.getWorld();
        Location e = p.getEyeLocation();
        Vector c = e.toVector().add(e.getDirection().multiply(3));
        return run(pl, 40, t -> {
            if (t % 2 == 0) {
                w.spawnParticle(Particle.SOUL_FIRE_FLAME, c.getX(), c.getY(), c.getZ(), 20, 0.3, 0.3, 0.3, 0.01);
                w.spawnParticle(Particle.FLAME, c.getX(), c.getY() + 1, c.getZ(), 10, 0.2, 0.2, 0.2, 0.02);
                w.spawnParticle(Particle.END_ROD, c.getX(), c.getY() - 1, c.getZ(), 8, 0.2, 0.2, 0.2, 0.02);
            }
        });
    }

    // ---------------------------------------------------------------- tunnel

    static BukkitTask tunnel(JavaPlugin pl, Player p) {
        World w = p.getWorld();
        Location e = p.getEyeLocation();
        Vector o = e.toVector();
        Vector d = e.getDirection().normalize();
        Vector[] uv = basis(d);
        Vector feet = p.getLocation().toVector().add(new Vector(0, 0.1, 0));
        return run(pl, 100, t -> {
            for (int k = 0; k < 6; k++) {
                double dist = (t * 0.35 + k * 2.0) % 12.0;
                double rad = 0.25 + dist * 0.22;
                Vector c = o.clone().add(d.clone().multiply(dist + 1.5));
                int n = 28;
                double dir = (k % 2 == 0) ? 1 : -1;
                for (int i = 0; i < n; i++) {
                    double a = i * Math.PI * 2 / n + t * 0.05 * dir;
                    dust(w, at(c, uv[0], uv[1], a, rad), 0, 255, 200, 0.9f);
                }
            }
            // светящаяся полоса на земле
            for (double s = -3; s <= 3; s += 0.25) {
                Vector pt = feet.clone().add(uv[0].clone().multiply(s));
                dust(w, pt, 40, 255, 220, 1.2f);
            }
            // белые искры вокруг
            if (t % 2 == 0) {
                for (int i = 0; i < 6; i++) {
                    Vector pt = o.clone().add(rnd().multiply(3 + R.nextDouble() * 6));
                    fx(w, Particle.END_ROD, pt);
                }
            }
        });
    }

    // ---------------------------------------------------------------- tornado

    static BukkitTask tornado(JavaPlugin pl, Player p) {
        World w = p.getWorld();
        Vector c = p.getLocation().toVector().add(flat(p).multiply(4));
        return run(pl, 120, t -> {
            for (int j = 0; j < 4; j++) {
                for (int s = 0; s <= 40; s++) {
                    double y = s / 40.0 * 5;
                    double r = 0.3 + y * 0.45;
                    double a = t * 0.3 + y * 2.2 + j * Math.PI / 2;
                    Vector pt = c.clone().add(new Vector(Math.cos(a) * r, y, Math.sin(a) * r));
                    dust(w, pt, 255, 0, 200 - (int) (y * 10), 1.1f);
                }
            }
            if (t % 2 == 0) {
                Vector top = c.clone().add(new Vector(0, 5, 0));
                for (int i = 0; i < 5; i++) fx(w, Particle.END_ROD, top.clone().add(rnd().multiply(1.5)));
            }
        });
    }

    // ---------------------------------------------------------------- geosphere

    static List<Vector[]> ico(int sub) {
        double g = (1 + Math.sqrt(5)) / 2;
        double[][] raw = {{-1, g, 0}, {1, g, 0}, {-1, -g, 0}, {1, -g, 0}, {0, -1, g}, {0, 1, g},
                {0, -1, -g}, {0, 1, -g}, {g, 0, -1}, {g, 0, 1}, {-g, 0, -1}, {-g, 0, 1}};
        List<Vector> v = new ArrayList<>();
        for (double[] r : raw) v.add(new Vector(r[0], r[1], r[2]).normalize());
        List<int[]> faces = new ArrayList<>(Arrays.asList(new int[][]{
                {0, 11, 5}, {0, 5, 1}, {0, 1, 7}, {0, 7, 10}, {0, 10, 11},
                {1, 5, 9}, {5, 11, 4}, {11, 10, 2}, {10, 7, 6}, {7, 1, 8},
                {3, 9, 4}, {3, 4, 2}, {3, 2, 6}, {3, 6, 8}, {3, 8, 9},
                {4, 9, 5}, {2, 4, 11}, {6, 2, 10}, {8, 6, 7}, {9, 8, 1}}));
        for (int s = 0; s < sub; s++) {
            Map<Long, Integer> cache = new HashMap<>();
            List<int[]> nf = new ArrayList<>();
            for (int[] f : faces) {
                int a = mid(v, cache, f[0], f[1]);
                int b = mid(v, cache, f[1], f[2]);
                int c = mid(v, cache, f[2], f[0]);
                nf.add(new int[]{f[0], a, c});
                nf.add(new int[]{f[1], b, a});
                nf.add(new int[]{f[2], c, b});
                nf.add(new int[]{a, b, c});
            }
            faces = nf;
        }
        Set<Long> seen = new HashSet<>();
        List<Vector[]> edges = new ArrayList<>();
        for (int[] f : faces) {
            for (int i = 0; i < 3; i++) {
                int a = f[i];
                int b = f[(i + 1) % 3];
                long k = (long) Math.min(a, b) * 100000L + Math.max(a, b);
                if (seen.add(k)) edges.add(new Vector[]{v.get(a), v.get(b)});
            }
        }
        return edges;
    }

    private static int mid(List<Vector> v, Map<Long, Integer> cache, int a, int b) {
        long k = (long) Math.min(a, b) * 100000L + Math.max(a, b);
        Integer i = cache.get(k);
        if (i != null) return i;
        Vector m = v.get(a).clone().add(v.get(b)).multiply(0.5).normalize();
        v.add(m);
        cache.put(k, v.size() - 1);
        return v.size() - 1;
    }

    static BukkitTask geosphere(JavaPlugin pl, Player p) {
        World w = p.getWorld();
        Vector c = p.getLocation().toVector().add(flat(p).multiply(9)).add(new Vector(0, 4, 0));
        List<Vector[]> edges = ico(1);
        double rad = 4;
        return run(pl, 160, t -> {
            double ay = t * 0.03;
            double ax = t * 0.017;
            if (t % 2 == 0) {
                for (Vector[] e : edges) {
                    for (int i = 0; i <= 6; i++) {
                        double s = i / 6.0;
                        Vector m = e[0].clone().multiply(1 - s).add(e[1].clone().multiply(s)).normalize();
                        m.rotateAroundY(ay).rotateAroundX(ax).multiply(rad).add(c);
                        dust(w, m, 170, 0, 255, 0.8f);
                    }
                }
            }
            for (int i = 0; i < 20; i++) {
                Vector m = rnd().multiply(rad * (0.3 + 0.7 * R.nextDouble())).add(c);
                fx(w, Particle.END_ROD, m);
            }
        });
    }

    // ---------------------------------------------------------------- ripples

    static BukkitTask ripples(JavaPlugin pl, Player p) {
        World w = p.getWorld();
        Vector c = p.getLocation().toVector().add(new Vector(0, 7, 0));
        return run(pl, 140, t -> {
            for (int b = Math.max(0, t - 44); b <= t; b++) {
                if (b % 6 != 0) continue;
                double r = (t - b) * 0.3;
                if (r < 0.3) continue;
                int n = (int) (r * 9) + 10;
                boolean black = (b / 6) % 2 == 0;
                for (int i = 0; i < n; i++) {
                    double a = i * Math.PI * 2 / n + (black ? 1 : -1) * r * 0.15;
                    Vector pt = c.clone().add(new Vector(Math.cos(a) * r, 0, Math.sin(a) * r));
                    if (black) dust(w, pt, 15, 15, 15, 1.6f);
                    else dust(w, pt, 160, 60, 255, 1.1f);
                }
            }
            for (int k = 0; k < 3; k++) {
                for (int i = 0; i < 24; i++) {
                    double a = i * Math.PI * 2 / 24 + t * 0.08 * (k + 1);
                    double rr = 0.6 + k * 0.6;
                    dust(w, c.clone().add(new Vector(Math.cos(a) * rr, 0.0, Math.sin(a) * rr)), 200, 120, 255, 0.7f);
                }
            }
        });
    }

    // ---------------------------------------------------------------- lightning

    static List<Vector> jag(Vector a, Vector b, int seg, double amp) {
        List<Vector> pts = new ArrayList<>();
        pts.add(a.clone());
        for (int i = 1; i < seg; i++) {
            double s = i / (double) seg;
            Vector m = a.clone().multiply(1 - s).add(b.clone().multiply(s));
            double f = amp * Math.min(1.0, Math.min(s, 1 - s) * 4);
            m.add(new Vector(R.nextGaussian() * f, R.nextGaussian() * f * 0.3, R.nextGaussian() * f));
            pts.add(m);
        }
        pts.add(b.clone());
        return pts;
    }

    static BukkitTask lightning(JavaPlugin pl, Player p) {
        World w = p.getWorld();
        Location eye = p.getEyeLocation();
        RayTraceResult res = w.rayTraceBlocks(eye, eye.getDirection(), 40);
        Vector target = res != null
                ? res.getHitPosition()
                : eye.toVector().add(eye.getDirection().multiply(30));
        List<List<Vector>> bolt = new ArrayList<>();
        return run(pl, 32, t -> {
            if (t % 4 == 0) {
                bolt.clear();
                Vector start = target.clone().add(new Vector(R.nextGaussian() * 3, 26, R.nextGaussian() * 3));
                List<Vector> main = jag(start, target, 16, 1.6);
                bolt.add(main);
                for (int i = 0; i < 4; i++) {
                    Vector from = main.get(2 + R.nextInt(main.size() - 4));
                    Vector to = from.clone().add(new Vector(R.nextGaussian() * 5, -4 - R.nextDouble() * 5, R.nextGaussian() * 5));
                    bolt.add(jag(from, to, 6, 0.8));
                }
                w.spawnParticle(Particle.ELECTRIC_SPARK, target.getX(), target.getY(), target.getZ(), 60, 1.0, 0.4, 1.0, 0.4);
                if (t % 16 == 0) {
                    w.playSound(new Location(w, target.getX(), target.getY(), target.getZ()),
                            Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5f, 1f);
                }
            }
            for (List<Vector> poly : bolt) {
                for (int i = 0; i < poly.size() - 1; i++) {
                    line(poly.get(i), poly.get(i + 1), 0.3, v -> {
                        fx(w, Particle.ELECTRIC_SPARK, v);
                        if (R.nextInt(3) == 0) fx(w, Particle.END_ROD, v);
                    });
                }
            }
        });
    }

    // ---------------------------------------------------------------- lissajous

    static BukkitTask lissajous(JavaPlugin pl, Player p) {
        World w = p.getWorld();
        Vector c = p.getLocation().toVector().add(flat(p).multiply(8)).add(new Vector(0, 5, 0));
        double[][] cv = {{3, 2, 0, 0}, {1, 2, Math.PI / 2, 1.0}, {2, 3, Math.PI / 4, 2.0}};
        return run(pl, 220, t -> {
            for (int k = 0; k < cv.length; k++) {
                for (int i = 0; i < 14; i++) {
                    double s = t * 0.07 + i * 0.012 + k * 1.7;
                    double amp = 3.2 - k * 0.5;
                    Vector pt = new Vector(
                            Math.sin(cv[k][0] * s + cv[k][2]) * amp,
                            Math.sin(cv[k][1] * s) * amp * 1.2,
                            Math.cos(s * 0.7 + k) * amp * 0.5);
                    pt.rotateAroundY(cv[k][3] + t * 0.012).add(c);
                    dust(w, pt, 255, 170 - k * 30, 30, 0.7f);
                    if (i == 0) fx(w, Particle.FLAME, pt);
                }
            }
        });
    }

    // ---------------------------------------------------------------- halo

    static BukkitTask halo(JavaPlugin pl, Player p) {
        World w = p.getWorld();
        Location e = p.getEyeLocation();
        Vector c = e.toVector().add(flat(p).multiply(9)).add(new Vector(0, 3, 0));
        Vector toPlayer = e.toVector().subtract(c).normalize();
        Vector[] uv = basis(toPlayer);
        return run(pl, 180, t -> {
            for (int j = 0; j < 3; j++) {
                double a = t * 0.03 + j * Math.PI * 2 / 3;
                Vector core = c.clone().add(new Vector(Math.cos(a) * 5, Math.sin(t * 0.05 + j * 2) * 1.8, Math.sin(a) * 5));
                if (t % 3 == 0) {
                    for (int i = 0; i < 6; i++) {
                        double rad = 0.5 * (i + 1) * (1 + 0.12 * Math.sin(t * 0.2 + i));
                        int n = 10 + 6 * i;
                        for (int q = 0; q < n; q++) {
                            double ang = q * Math.PI * 2 / n + t * 0.02 * (i % 2 == 0 ? 1 : -1);
                            fx(w, Particle.END_ROD, at(core, uv[0], uv[1], ang, rad));
                        }
                    }
                }
                dust(w, core, 200, 150, 120, 2.5f);
                if (t % 40 == j * 10) {
                    for (int s = 0; s < 24; s++) {
                        Vector d = rnd();
                        for (int k = 1; k <= 10; k++) {
                            fx(w, Particle.END_ROD, core.clone().add(d.clone().multiply(k * 0.45)));
                        }
                    }
                }
            }
        });
    }

    // ---------------------------------------------------------------- wave

    static BukkitTask wave(JavaPlugin pl, Player p) {
        World w = p.getWorld();
        Vector f = flat(p);
        Vector side = new Vector(-f.getZ(), 0, f.getX());
        Vector s0 = p.getLocation().toVector().add(new Vector(0, 0.15, 0)).add(f.clone().multiply(1.5));
        return run(pl, 100, t -> {
            for (double s = 0; s < 22; s += 0.15) {
                Vector base = s0.clone()
                        .add(f.clone().multiply(s))
                        .add(side.clone().multiply(Math.sin(s * 0.9 - t * 0.15) * 1.6))
                        .add(new Vector(0, 0.35 * Math.sin(s * 2 + t * 0.1) + 0.35, 0));
                Vector j = new Vector(R.nextGaussian() * 0.12, R.nextGaussian() * 0.12, R.nextGaussian() * 0.12);
                dust(w, base.clone().add(j), 210, 0, 25, 1.3f);
                if (R.nextInt(3) == 0) dust(w, base.clone().add(j.multiply(2)), 25, 0, 0, 1.0f);
                if (R.nextInt(40) == 0) fx(w, Particle.SOUL_FIRE_FLAME, base);
            }
        });
    }

    // ---------------------------------------------------------------- beam

    static final Vector[] OCT = {
            new Vector(1, 0, 0), new Vector(-1, 0, 0), new Vector(0, 1, 0),
            new Vector(0, -1, 0), new Vector(0, 0, 1), new Vector(0, 0, -1)};
    static final Vector[] TETRA = {
            new Vector(1, 1, 1), new Vector(1, -1, -1), new Vector(-1, 1, -1), new Vector(-1, -1, 1)};

    static void wire(World w, Vector[] vs, Vector c, double r, double ay, double ax, int cr, int cg, int cb) {
        Vector[] q = new Vector[vs.length];
        for (int i = 0; i < vs.length; i++) {
            q[i] = vs[i].clone().normalize().rotateAroundY(ay).rotateAroundX(ax).multiply(r).add(c);
        }
        for (int i = 0; i < vs.length; i++) {
            for (int j = i + 1; j < vs.length; j++) {
                double dot = vs[i].clone().normalize().dot(vs[j].clone().normalize());
                if (dot > -0.9) line(q[i], q[j], 0.25, v -> dust(w, v, cr, cg, cb, 0.9f));
            }
        }
    }

    static BukkitTask beam(JavaPlugin pl, Player p) {
        World w = p.getWorld();
        Location e = p.getEyeLocation();
        RayTraceResult res = w.rayTraceBlocks(e, e.getDirection(), 40);
        Vector end = res != null
                ? res.getHitPosition()
                : e.toVector().add(e.getDirection().multiply(28));
        Vector start = e.toVector().add(e.getDirection().multiply(1.2)).add(new Vector(0, -0.4, 0));
        return run(pl, 110, t -> {
            Vector d = end.clone().subtract(start);
            double len = d.length();
            if (len < 0.5) return;
            d.multiply(1.0 / len);
            Vector[] uv = basis(d);
            List<Vector> pts = new ArrayList<>();
            for (double s = 0; s <= len; s += 0.35) {
                double f = Math.min(1.0, Math.min(s, len - s) / 3.0) * 0.18;
                Vector pt = start.clone().add(d.clone().multiply(s))
                        .add(uv[0].clone().multiply(R.nextGaussian() * f))
                        .add(uv[1].clone().multiply(R.nextGaussian() * f));
                pts.add(pt);
                dust(w, pt, 185, 0, 255, 1.0f);
                if (R.nextInt(4) == 0) fx(w, Particle.END_ROD, pt);
            }
            for (int b = 0; b < 5; b++) {
                Vector cur = pts.get(R.nextInt(pts.size())).clone();
                for (int k = 0; k < 5; k++) {
                    Vector nx = cur.clone().add(rnd().multiply(0.9));
                    line(cur, nx, 0.2, v -> dust(w, v, 230, 150, 255, 0.8f));
                    cur = nx;
                }
            }
            wire(w, OCT, end, 1.6, t * 0.05, t * 0.03, 200, 80, 255);
            wire(w, TETRA, end, 2.6, -t * 0.04, t * 0.02, 255, 255, 255);
        });
    }
}
