package com.particleshow;

import com.particleshow.show.Kind;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.particle.DefaultParticleType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

/** Регистрация 5 новых частиц: particleshow:glow / spark / star / ring / ember (работают и в /particle). */
public final class ModParticles {
    private static final Map<Kind, DefaultParticleType> TYPES = new EnumMap<>(Kind.class);

    private ModParticles() {}

    public static void register() {
        for (Kind k : Kind.values()) {
            DefaultParticleType type = FabricParticleTypes.simple(true);
            Registry.register(Registries.PARTICLE_TYPE, new Identifier(ParticleShowMod.ID, k.name().toLowerCase()), type);
            TYPES.put(k, type);
        }
    }

    public static DefaultParticleType of(Kind k) { return TYPES.get(k); }
}
