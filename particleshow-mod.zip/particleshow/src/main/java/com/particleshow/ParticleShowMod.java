package com.particleshow;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.particleshow.show.Show;
import com.particleshow.show.ShowRegistry;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.command.CommandSource;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

public class ParticleShowMod implements ModInitializer {
    public static final String ID = "particleshow";
    public static final Identifier PLAY = new Identifier(ID, "play");

    @Override
    public void onInitialize() {
        ModParticles.register();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("particleshow")
                        .requires(src -> src.hasPermissionLevel(2))
                        .then(CommandManager.literal("list").executes(ctx -> {
                            ctx.getSource().sendFeedback(() -> Text.literal("Доступные шоу:"), false);
                            for (Show s : ShowRegistry.all()) {
                                String line = " - " + s.id() + "  (" + (s.duration() / 20) + " сек)  " + s.title();
                                ctx.getSource().sendFeedback(() -> Text.literal(line), false);
                            }
                            return 1;
                        }))
                        .then(CommandManager.literal("stop").executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                            PacketByteBuf buf = PacketByteBufs.create();
                            buf.writeString("stop");
                            buf.writeDouble(0).writeDouble(0).writeDouble(0).writeFloat(1f).writeLong(0L);
                            for (ServerPlayerEntity pl : p.getServerWorld().getPlayers())
                                ServerPlayNetworking.send(pl, PLAY, PacketByteBufs.copy(buf));
                            return 1;
                        }))
                        .then(CommandManager.literal("play")
                                .then(CommandManager.argument("show", StringArgumentType.word())
                                        .suggests((ctx, b) -> CommandSource.suggestMatching(ShowRegistry.ids(), b))
                                        .executes(ctx -> play(ctx, 1f))
                                        .then(CommandManager.argument("scale", FloatArgumentType.floatArg(0.2f, 3f))
                                                .executes(ctx -> play(ctx, FloatArgumentType.getFloat(ctx, "scale"))))))));
    }

    private static int play(CommandContext<ServerCommandSource> ctx, float scale) throws CommandSyntaxException {
        String id = StringArgumentType.getString(ctx, "show").toLowerCase();
        ServerCommandSource src = ctx.getSource();
        Show show = ShowRegistry.get(id);
        if (show == null) {
            src.sendError(Text.literal("Неизвестное шоу: " + id + ". Список: /particleshow list"));
            return 0;
        }
        ServerPlayerEntity p = src.getPlayerOrThrow();
        Vec3d look = p.getRotationVec(1f);
        Vec3d dir = new Vec3d(look.x, 0, look.z).normalize();
        if (dir.lengthSquared() < 1e-6) dir = new Vec3d(0, 0, 1);
        Vec3d c = p.getPos().add(dir.multiply(show.distance() * scale));
        long seed = p.getServerWorld().getRandom().nextLong();

        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeString(id);
        buf.writeDouble(c.x).writeDouble(c.y).writeDouble(c.z);
        buf.writeFloat(scale);
        buf.writeLong(seed);
        for (ServerPlayerEntity pl : p.getServerWorld().getPlayers())
            ServerPlayNetworking.send(pl, PLAY, PacketByteBufs.copy(buf));

        src.sendFeedback(() -> Text.literal("Запущено шоу «" + show.id() + "» (" + (show.duration() / 20) + " сек). Смотри вперёд!"), true);
        return 1;
    }
}
