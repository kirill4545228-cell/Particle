package com.particleshow.client;

import com.particleshow.show.ShowContext;
import com.particleshow.show.Spec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

final class ClientShowContext implements ShowContext {
    private static final int PER_TICK_LIMIT = 4200;

    private final Vec3d center;
    private final double scale;
    private final Random rng;
    private final Vec3d toViewer;
    private int emittedThisTick;
    private boolean warned;

    ClientShowContext(Vec3d center, double scale, long seed, Vec3d toViewer) {
        this.center = center;
        this.scale = scale;
        this.rng = new Random(seed);
        this.toViewer = toViewer;
    }

    void newTick() { emittedThisTick = 0; }

    @Override public Vec3d center() { return center; }
    @Override public double scale() { return scale; }
    @Override public Random rng() { return rng; }
    @Override public Vec3d toViewer() { return toViewer; }

    @Override
    public void emit(Spec s) {
        if (emittedThisTick >= PER_TICK_LIMIT || ShowParticle.LIVE.get() >= ShowParticle.LIMIT) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientWorld world = mc.world;
        SpriteProvider sprites = ParticleShowClient.PROVIDERS.get(s.kind);
        if (world == null) return;
        if (sprites == null) {
            if (!warned && mc.player != null) {
                warned = true;
                mc.player.sendMessage(net.minecraft.text.Text.literal("[ParticleShow] спрайты частиц не загружены (проверь ресурсы мода)"), false);
            }
            return;
        }
        s.vx *= scale; s.vy *= scale; s.vz *= scale;
        s.gravity *= (float) scale; s.rise *= (float) scale; s.grow *= (float) scale;
        s.size *= (float) Math.sqrt(scale);
        mc.particleManager.addParticle(new ShowParticle(world, sprites, s));
        emittedThisTick++;
    }

    @Override
    public void say(String text) {
        MinecraftClient.getInstance().inGameHud.setOverlayMessage(net.minecraft.text.Text.literal(text), false);
    }

    @Override
    public void sound(String id, float vol, float pitch) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Identifier ident = Identifier.tryParse(id);
        if (ident == null) return;
        SoundEvent ev = Registries.SOUND_EVENT.get(ident);
        if (ev == null) return;
        mc.getSoundManager().play(PositionedSoundInstance.master(ev, pitch, Math.min(1f, vol)));
    }
}
