package com.particleshow.client;

import com.particleshow.show.Show;
import com.particleshow.show.ShowRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Клиентский планировщик: каждый тик двигает все запущенные шоу вперёд. */
public final class ShowManager {
    private static final Logger LOG = LoggerFactory.getLogger("particleshow");

    private static final class Running {
        final Show show;
        final ClientShowContext ctx;
        int t;
        Running(Show show, ClientShowContext ctx) { this.show = show; this.ctx = ctx; }
    }

    private static final List<Running> RUNNING = new ArrayList<>();
    private static int idle;

    private ShowManager() {}

    public static void start(String id, Vec3d center, double scale, long seed) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (id.equals("stop")) {
            RUNNING.clear();
            return;
        }
        Show show = ShowRegistry.get(id);
        if (show == null || mc.player == null) return;
        Vec3d to = mc.player.getPos().subtract(center);
        Vec3d horiz = new Vec3d(to.x, 0, to.z).normalize();
        if (horiz.lengthSquared() < 1e-6) horiz = new Vec3d(0, 0, 1);
        RUNNING.add(new Running(show, new ClientShowContext(center, scale, seed, horiz)));
        mc.player.sendMessage(net.minecraft.text.Text.literal("[ParticleShow] запуск «" + show.id() + "», спрайтов загружено: "
                + ParticleShowClient.PROVIDERS.size() + "/5"), false);
    }

    public static void tick(MinecraftClient mc) {
        if (mc.world == null) {
            RUNNING.clear();
            ShowParticle.LIVE.set(0);
            return;
        }
        if (mc.isPaused()) return;
        if (RUNNING.isEmpty()) {
            if (++idle > 400) ShowParticle.LIVE.set(0);
            return;
        }
        idle = 0;
        Iterator<Running> it = RUNNING.iterator();
        while (it.hasNext()) {
            Running r = it.next();
            try {
                r.ctx.newTick();
                r.show.tick(r.ctx, r.t++);
            } catch (Throwable e) {
                LOG.error("Show {} crashed, stopping it", r.show.id(), e);
                it.remove();
                continue;
            }
            if (r.t >= r.show.duration()) it.remove();
        }
    }
}
