package com.particleshow.client;

import com.particleshow.show.Kind;
import com.particleshow.show.Spec;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.DefaultParticleType;

import java.util.concurrent.atomic.AtomicInteger;

/** Универсальная частица мода: свечение (аддитивное смешивание), плавное появление/затухание, рост, дрейф, мерцание. */
public class ShowParticle extends SpriteBillboardParticle {
    /** Сколько частиц шоу сейчас живо (в очереди ParticleManager максимум 16384 на тип отрисовки). */
    public static final AtomicInteger LIVE = new AtomicInteger();
    public static final int LIMIT = 15500;

    private final float baseAlpha, drag, gravity, rise, grow, r0, g0, b0;
    private final int fadeIn, fadeOut;
    private final boolean twinkle, additive;
    private final float phase;
    private boolean counted = true;

    public ShowParticle(ClientWorld world, SpriteProvider sprites, Spec s) {
        super(world, s.x, s.y, s.z, 0, 0, 0);
        this.velocityX = s.vx;
        this.velocityY = s.vy;
        this.velocityZ = s.vz;
        this.maxAge = Math.max(1, s.life);
        this.scale = s.size;
        this.r0 = ((s.rgb >> 16) & 255) / 255f;
        this.g0 = ((s.rgb >> 8) & 255) / 255f;
        this.b0 = (s.rgb & 255) / 255f;
        this.red = r0;
        this.green = g0;
        this.blue = b0;
        this.baseAlpha = s.alpha;
        this.drag = s.drag;
        this.gravity = s.gravity;
        this.rise = s.rise;
        this.grow = s.grow;
        this.fadeIn = Math.max(0, s.fadeIn);
        this.fadeOut = s.fadeOut >= 0 ? s.fadeOut : Math.min(this.maxAge / 3, 20);
        this.twinkle = s.twinkle;
        this.additive = s.additive;
        this.phase = this.random.nextFloat() * 6.28f;
        this.collidesWithWorld = false;
        this.gravityStrength = 0f;
        this.alpha = this.fadeIn > 0 ? 0f : this.baseAlpha;
        this.setSprite(sprites.getSprite(this.random));
        LIVE.incrementAndGet();
    }

    @Override
    public void tick() {
        this.prevPosX = this.x;
        this.prevPosY = this.y;
        this.prevPosZ = this.z;
        if (this.age++ >= this.maxAge) {
            die();
            return;
        }
        this.velocityY -= gravity;
        int left = this.maxAge - this.age;
        if (this.fadeOut > 0 && left < this.fadeOut) this.velocityY += rise;
        this.x += this.velocityX;
        this.y += this.velocityY;
        this.z += this.velocityZ;
        this.velocityX *= drag;
        this.velocityY *= drag;
        this.velocityZ *= drag;
        if (grow != 0f) this.scale = Math.max(0.001f, this.scale + grow);

        float a = baseAlpha;
        if (fadeIn > 0 && this.age < fadeIn) a *= (this.age + 1f) / fadeIn;
        if (fadeOut > 0 && left < fadeOut) a *= left / (float) fadeOut;
        if (twinkle) a *= 0.65f + 0.35f * (float) Math.sin(this.age * 0.9f + phase);
        a = Math.max(0f, Math.min(1f, a));
        // Шейдер частиц отбрасывает пиксели с alpha < 0.1, поэтому "дымку" (низкая прозрачность)
        // рисуем с alpha 0.5, а яркость переносим в цвет.
        if (baseAlpha < 0.5f) {
            if (a < baseAlpha * 0.15f) {
                this.alpha = 0f;
            } else {
                float k = a / 0.5f;
                this.alpha = 0.5f;
                this.red = r0 * k;
                this.green = g0 * k;
                this.blue = b0 * k;
            }
        } else {
            this.alpha = a;
        }
    }

    private void die() {
        if (counted) {
            counted = false;
            LIVE.decrementAndGet();
        }
        this.markDead();
    }

    @Override
    public ParticleTextureSheet getType() {
        return ParticleTextureSheet.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public int getBrightness(float tint) { return 15728880; }

    /** Фабрика для частиц, вызванных обычной командой /particle particleshow:glow ... */
    public static class Factory implements ParticleFactory<DefaultParticleType> {
        private final SpriteProvider sprites;
        private final Kind kind;

        public Factory(SpriteProvider sprites, Kind kind) {
            this.sprites = sprites;
            this.kind = kind;
        }

        @Override
        public Particle createParticle(DefaultParticleType type, ClientWorld world, double x, double y, double z,
                                       double vx, double vy, double vz) {
            Spec s = new Spec(kind).pos(x, y, z).vel(vx, vy, vz).life(40).size(0.3).color(0xFFFFFF).fade(2, 12);
            return new ShowParticle(world, sprites, s);
        }
    }
}
