package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.Random;

/** Северное сияние: 5 колышущихся занавесей шириной ~200 блоков, зелёный -> бирюзовый -> фиолетовый, мерцающие звёзды. */
public final class AuroraShow implements Show {
    @Override public String id() { return "aurora"; }
    @Override public String title() { return "Северное сияние над горизонтом"; }
    @Override public int duration() { return 900; }
    @Override public double distance() { return 90; }

    @Override
    public void tick(ShowContext c, int t) {
        Random r = c.rng();
        if (t % 150 == 0) c.sound("minecraft:block.amethyst_block.chime", 0.6f, 0.6f + r.nextFloat() * 0.4f);
        double env = Fx.ramp(t, 0, 100) * (1 - Fx.ramp(t, 800, 900));
        if (env < 0.01) return;
        Vec3d v = c.toViewer();
        Vec3d rt = new Vec3d(-v.z, 0, v.x), away = v.negate();
        for (int k = 0; k < 5; k++) {
            double baseDepth = 10 + k * 14, baseY = 70 + k * 6;
            int n = (int) (100 * env);
            for (int i = 0; i < n; i++) {
                double x = (r.nextDouble() * 2 - 1) * (110 - 6 * k);
                double phase = x * 0.045 + t * 0.012 + k * 1.7;
                double off = 16 * Math.sin(phase) + 7 * Math.sin(x * 0.11 - t * 0.03 + k);
                double bright = 0.5 + 0.5 * Math.sin(x * 0.06 + t * 0.04 + k * 2.1);
                double hgt = 22 + 24 * (0.5 + 0.5 * Math.sin(x * 0.05 - t * 0.017 + k));
                double f = r.nextDouble();
                double y = baseY + 6 * Math.sin(phase * 0.7) + f * hgt;
                double d = baseDepth + off;
                int col = f < 0.5 ? Fx.mix(0x30FF90, 0x28E0C8, f * 2) : Fx.mix(0x28E0C8, 0xA05CFF, (f - 0.5) * 2);
                c.emit(new Spec(Kind.GLOW).pos(c.at(rt.x * x + away.x * d, y, rt.z * x + away.z * d)).vel(0, 0.02, 0)
                        .life(10).size(3.2 + r.nextDouble() * 1.5).color(col)
                        .alpha(0.10 + 0.22 * bright * (1 - f * 0.6)).fade(3, 6));
            }
        }
        for (int i = 0; i < 8; i++) {
            double a = r.nextDouble() * Fx.TAU, rad = r.nextDouble() * 130, y = 100 + r.nextDouble() * 60;
            c.emit(new Spec(Kind.STAR).pos(c.at(Math.cos(a) * rad, y, Math.sin(a) * rad)).life(20).size(0.5)
                    .color(0xFFFFFF).alpha(0.8).fade(3, 10).twinkle());
        }
        if (t % 70 == 35) {
            double x0 = (r.nextDouble() - 0.5) * 120, y0 = 140 + r.nextDouble() * 30;
            for (int i = 0; i < 24; i++)
                c.emit(new Spec(Kind.SPARK).pos(c.at(rt.x * (x0 - i * 1.5) + away.x * 60, y0 - i * 0.8, rt.z * (x0 - i * 1.5) + away.z * 60))
                        .life(10 + i / 2).size(0.7 - i * 0.02).color(0xFFFFFF).fade(0, 8));
        }
    }
}
