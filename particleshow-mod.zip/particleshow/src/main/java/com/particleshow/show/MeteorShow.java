package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Метеоритный дождь: 22 метеора с огненными хвостами и один огромный в финале; каждый падает с ударной волной и обломками. */
public final class MeteorShow implements Show {
    private static final class M {
        final int t0, flight;
        final double sx, sz, tx, tz, size;
        M(int t0, int flight, double sx, double sz, double tx, double tz, double size) {
            this.t0 = t0; this.flight = flight; this.sx = sx; this.sz = sz; this.tx = tx; this.tz = tz; this.size = size;
        }
    }

    private static final double SY = 120;
    private final List<M> ms = new ArrayList<>();

    public MeteorShow() {
        Random r = new Random(77);
        for (int i = 0; i < 22; i++) {
            double tx = (r.nextDouble() - 0.5) * 110, tz = (r.nextDouble() - 0.5) * 50, a = -0.5 + r.nextDouble();
            ms.add(new M(10 + i * 30 + r.nextInt(20), 40 + r.nextInt(15), tx + 100 * Math.cos(a), tz + 100 * Math.sin(a), tx, tz, 1));
        }
        ms.add(new M(560, 90, 110, 30, 0, 0, 3));
    }

    @Override public String id() { return "meteors"; }
    @Override public String title() { return "Метеоритный дождь и огромный метеорит"; }
    @Override public int duration() { return 800; }
    @Override public double distance() { return 70; }

    @Override
    public void tick(ShowContext c, int t) {
        Random r = c.rng();
        for (M m : ms) {
            if (t == m.t0) c.sound("minecraft:entity.firework_rocket.launch", m.size > 1 ? 1f : 0.4f, m.size > 1 ? 0.5f : 0.8f);
            if (t >= m.t0 && t < m.t0 + m.flight) {
                double tau = (t - m.t0) / (double) m.flight;
                Vec3d s = new Vec3d(m.sx, SY, m.sz), e = new Vec3d(m.tx, 0.5, m.tz);
                Vec3d pos = Fx.lerp(s, e, tau);
                Vec3d dir = e.subtract(s).normalize();
                Vec3d vel = e.subtract(s).multiply(1.0 / m.flight);
                Vec3d w = c.at(pos.x, pos.y, pos.z);
                c.emit(new Spec(Kind.GLOW).pos(w).life(2).size(1.4 * m.size).color(0xFFE6B8).fade(0, 1));
                c.emit(new Spec(Kind.STAR).pos(w).life(2).size(2.2 * m.size).color(0xFF8A30).alpha(0.8).fade(0, 1));
                int n = (int) (28 * m.size);
                double len = 28 * m.size;
                for (int i = 0; i < n; i++) {
                    double sd = r.nextDouble() * len;
                    Vec3d q = pos.subtract(dir.multiply(sd));
                    c.emit(new Spec(Kind.GLOW).pos(c.at(q.x + r.nextGaussian() * 0.3, q.y + r.nextGaussian() * 0.3, q.z + r.nextGaussian() * 0.3))
                            .vel(vel.multiply(0.15)).life(14 + r.nextInt(10)).size(0.6 * m.size)
                            .color(Fx.mix(0xFFB060, 0xFF3010, sd / len)).alpha(0.8).fade(1, 10));
                }
                for (int i = 0; i < 4 * m.size; i++)
                    c.emit(new Spec(Kind.EMBER).pos(w).vel(r.nextGaussian() * 0.05, r.nextGaussian() * 0.05, r.nextGaussian() * 0.05)
                            .gravity(0.02).life(30).size(0.3).color(0xFFA040).fade(1, 15));
            }
            if (t == m.t0 + m.flight) impact(c, m, r);
        }
    }

    private void impact(ShowContext c, M m, Random r) {
        Vec3d g = c.at(m.tx, 0.5, m.tz);
        double k = m.size;
        c.emit(new Spec(Kind.GLOW).pos(g).life(8).size(9 * k).color(0xFFFFFF).alpha(0.9).fade(0, 7));
        Fx.shock(c, g, 1.6 * k, (int) (120 * k), 0xFF8A40, (int) (28 * (0.7 + 0.3 * k)), 0.6 * k);
        c.emit(new Spec(Kind.RING).pos(g).life(20).size(0.6).grow(1.2 * k).color(0xFFB070).alpha(0.8).fade(1, 15));
        for (int i = 0; i < 120; i++)
            c.emit(new Spec(Kind.EMBER).pos(g).vel(r.nextGaussian() * 0.5 * k, 0.8 + r.nextDouble() * 1.2 * k, r.nextGaussian() * 0.5 * k)
                    .gravity(0.05).life(50).size(0.4).color(Fx.mix(0xFFC060, 0xFF4010, r.nextDouble())).fade(1, 25));
        for (int i = 0; i < 90; i++)
            c.emit(new Spec(Kind.GLOW).pos(g).vel(r.nextGaussian() * 0.15 * k, 0.3 + r.nextDouble() * 0.5 * k, r.nextGaussian() * 0.15 * k)
                    .drag(0.97).life(60).size(1.2 * k).color(0xA08060).alpha(0.3).fade(5, 40));
        c.sound("minecraft:entity.generic.explode", k > 1 ? 1f : 0.5f, k > 1 ? 0.5f : 0.8f);
    }
}
