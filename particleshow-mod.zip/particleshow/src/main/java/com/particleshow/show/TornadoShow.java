package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.Random;

/** Колоссальный торнадо: воронка 95 блоков, мусор, пыль у основания, грозовая туча и молнии. Лучше смотреть ночью. */
public final class TornadoShow implements Show {
    private static final double H = 95;

    @Override public String id() { return "tornado"; }
    @Override public String title() { return "Торнадо с тучей, мусором и молниями"; }
    @Override public int duration() { return 700; }
    @Override public double distance() { return 75; }

    private static double sx(double t, double y) { return 6 * Math.sin(t * 0.02 + y * 0.03); }
    private static double sz(double t, double y) { return 5 * Math.cos(t * 0.017 + y * 0.025); }

    @Override
    public void tick(ShowContext c, int t) {
        Random r = c.rng();
        if (t % 160 == 0) c.sound("minecraft:entity.lightning_bolt.thunder", 0.7f, 0.6f);
        double grow = Fx.smooth(t / 100.0), die = 1 - Fx.smooth((t - 600) / 100.0);
        if (grow * die < 0.02) return;
        int n = (int) (340 * die);
        for (int i = 0; i < n; i++) {
            double y = H * grow * Math.pow(r.nextDouble(), 0.85);
            double rr = (3 + 25 * Math.pow(y / H, 1.7)) * (0.7 + 0.3 * r.nextDouble());
            double ang = r.nextDouble() * Fx.TAU, w = 0.12 - 0.05 * y / H;
            Vec3d pos = c.at(sx(t, y) + Math.cos(ang) * rr, y, sz(t, y) + Math.sin(ang) * rr);
            c.emit(new Spec(Kind.GLOW).pos(pos).vel(-Math.sin(ang) * w * rr, 0.15, Math.cos(ang) * w * rr).life(5)
                    .size(0.8 + 0.4 * r.nextDouble()).color(Fx.mix(0x8E9BB0, 0xE8F0FF, r.nextDouble())).alpha(0.33).fade(1, 3));
        }
        for (int i = 0; i < (int) (36 * die); i++) {
            double y = r.nextDouble() * 14 * grow;
            double rr = (3 + 25 * Math.pow(y / H, 1.7)) * (0.8 + 0.5 * r.nextDouble());
            double ang = r.nextDouble() * Fx.TAU, w = 0.12;
            c.emit(new Spec(Kind.EMBER).pos(c.at(sx(t, y) + Math.cos(ang) * rr, y, sz(t, y) + Math.sin(ang) * rr))
                    .vel(-Math.sin(ang) * w * rr * 1.2, 0.25, Math.cos(ang) * w * rr * 1.2).life(10).size(0.3)
                    .color(0x5A4632).solid().fade(0, 3));
        }
        if (grow > 0.8) {
            for (int i = 0; i < (int) (36 * die); i++) {
                double ang = r.nextDouble() * Fx.TAU, rad = r.nextDouble() * 75;
                c.emit(new Spec(Kind.GLOW).pos(c.at(Math.cos(ang) * rad, 98 + r.nextDouble() * 10, Math.sin(ang) * rad))
                        .vel(-Math.sin(ang) * 0.2, 0, Math.cos(ang) * 0.2).life(40).size(7 + 3 * r.nextDouble())
                        .color(0x7A8498).alpha(0.16).fade(10, 20));
            }
        }
        for (int i = 0; i < (int) (24 * die); i++) {
            double ang = r.nextDouble() * Fx.TAU, rad = 10 + r.nextDouble() * 28;
            c.emit(new Spec(Kind.GLOW).pos(c.at(sx(t, 0) + Math.cos(ang) * rad, 0.5 + r.nextDouble() * 2, sz(t, 0) + Math.sin(ang) * rad))
                    .vel(-Math.sin(ang) * 0.18 * rad * 0.2, 0.05, Math.cos(ang) * 0.18 * rad * 0.2).life(18).size(2.4)
                    .color(0xCDB98E).alpha(0.22).fade(3, 10));
        }
        if (t > 60 && t < 620 && r.nextInt(14) == 0) {
            double bx = (r.nextDouble() - 0.5) * 50, bz = (r.nextDouble() - 0.5) * 50;
            Fx.bolt(c, c.at(sx(t, 98) + bx * 0.3, 98, sz(t, 98) + bz * 0.3), c.at(bx, 0.5, bz), 0xCFE0FF, 0.6, 6, 4);
            if (r.nextInt(3) == 0) c.sound("minecraft:entity.lightning_bolt.thunder", 0.5f, 0.8f);
        }
    }
}
