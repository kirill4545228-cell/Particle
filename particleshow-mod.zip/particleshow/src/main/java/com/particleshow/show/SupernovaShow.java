package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.Random;

/** Сверхновая: звезда сжимается и пульсирует, потом взрыв - три сферические оболочки, экваториальное кольцо, две струи и кольцо ударной волны. */
public final class SupernovaShow implements Show {
    private static final double PY = 55;

    @Override public String id() { return "supernova"; }
    @Override public String title() { return "Сверхновая: коллапс звезды и грандиозный взрыв"; }
    @Override public int duration() { return 620; }
    @Override public double distance() { return 110; }

    @Override
    public void tick(ShowContext c, int t) {
        Random r = c.rng();
        Vec3d P = c.at(0, PY, 0);
        if (t == 0) c.sound("minecraft:block.beacon.activate", 1f, 0.5f);
        if (t < 200) {
            double k = t / 200.0;
            double rad = 30 * (1 - Fx.smooth(k)) + 2;
            double pulse = 1 + 0.3 * Math.sin(t * (0.1 + 0.25 * k));
            c.emit(new Spec(Kind.GLOW).pos(P).life(3).size((1.5 + 3 * k) * pulse).color(Fx.mix(0xFFC080, 0xFFFFFF, k)).fade(1, 2));
            c.emit(new Spec(Kind.STAR).pos(P).life(3).size((3 + 6 * k) * pulse).color(0xFF7040).alpha(0.6).fade(1, 2));
            for (int i = 0; i < 40; i++) {
                Vec3d d = Fx.randDir(r);
                Vec3d p = c.at(d.x * rad, PY + d.y * rad, d.z * rad);
                c.emit(new Spec(Kind.GLOW).pos(p).vel(d.multiply(-rad / 14.0)).life(14).size(0.5).color(Fx.mix(0xFF8040, 0xFFE0B0, k)).alpha(0.8).fade(2, 8));
            }
        }
        if (t == 200) {
            c.sound("minecraft:entity.generic.explode", 1f, 0.5f);
            c.sound("minecraft:entity.warden.sonic_boom", 1f, 0.5f);
            c.emit(new Spec(Kind.GLOW).pos(P).life(20).size(30).color(0xFFFFFF).alpha(0.95).fade(1, 18));
            double[] sp = {1.2, 2.0, 3.1};
            int[] col = {0xFF6030, 0xFFC060, 0x9CC8FF};
            for (int sh = 0; sh < 3; sh++)
                for (int i = 0; i < 900; i++)
                    c.emit(new Spec(Kind.GLOW).pos(P).vel(Fx.randDir(r).multiply(sp[sh] * (0.96 + 0.08 * r.nextDouble())))
                            .drag(0.975).life(260).size(0.6).color(Fx.mix(col[sh], 0xFFFFFF, r.nextDouble() * 0.3)).alpha(0.85).fade(4, 120));
            for (int i = 0; i < 500; i++) {
                double a = i * Fx.TAU / 500;
                c.emit(new Spec(Kind.GLOW).pos(P).vel(Math.cos(a) * 2.4, r.nextGaussian() * 0.04, Math.sin(a) * 2.4)
                        .drag(0.975).life(240).size(0.65).color(0xFFE0A0).fade(4, 110));
            }
            Fx.shock(c, c.at(0, 0.5, 0), 3.0, 260, 0xFFB070, 60, 0.8);
        }
        if (t >= 200 && t < 330) {
            for (int sg = -1; sg <= 1; sg += 2)
                for (int i = 0; i < 20; i++) {
                    double a = r.nextDouble() * Fx.TAU;
                    c.emit(new Spec(Kind.GLOW).pos(P).vel(Math.cos(a) * 0.12, sg * (2.4 + 1.2 * r.nextDouble()), Math.sin(a) * 0.12)
                            .drag(0.985).life(90).size(0.55).color(Fx.mix(0xCFE6FF, 0x6C8CFF, r.nextDouble())).fade(2, 40));
                }
        }
        if (t >= 205 && t < 520 && t % 12 == 0)
            c.emit(new Spec(Kind.RING).pos(P).life(60).size(1).grow(1.6).color(0xFFB070).alpha(0.6).fade(2, 40));
        if (t >= 230 && t < 560) {
            for (int i = 0; i < 12; i++) {
                Vec3d d = Fx.randDir(r).multiply(1.0 + r.nextDouble() * 2.0);
                c.emit(new Spec(Kind.GLOW).pos(P).vel(d).drag(0.97).life(110).size(2.5).color(Fx.mix(0xFF4A2A, 0x8A3AFF, r.nextDouble()))
                        .alpha(0.12).fade(20, 60));
            }
        }
    }
}
