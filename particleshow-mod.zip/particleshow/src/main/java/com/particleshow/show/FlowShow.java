package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.Random;

/**
 * Тихий поток: невидимая точка, вокруг неё медленно и плавно плывут 2000 маленьких полосок из частиц.
 * Все движутся в одну сторону (вокруг общей оси, у каждой своя лёгкая орбита), вместе они образуют живой шар.
 */
public final class FlowShow implements Show {
    private static final int N = 2000;
    private static final double PY = 45;

    private final Vec3d[] axis = new Vec3d[N], v0 = new Vec3d[N];
    private final double[] radius = new double[N], omega = new double[N], size = new double[N], alpha = new double[N], phase = new double[N];
    private final int[] color = new int[N];

    public FlowShow() {
        Random r = new Random(5);
        int[] pal = {0x9CC8FF, 0xFFFFFF, 0xC8B4FF, 0x7FE0FF};
        for (int i = 0; i < N; i++) {
            Vec3d tilt = Fx.randDir(r).multiply(Math.tan(0.5 * r.nextDouble()));
            axis[i] = new Vec3d(0, 1, 0).add(tilt).normalize();
            v0[i] = Fx.randDir(r);
            radius[i] = 12 + 18 * Math.pow(r.nextDouble(), 0.8);
            omega[i] = 0.012 + 0.012 * r.nextDouble();
            size[i] = 0.26 + 0.2 * r.nextDouble();
            alpha[i] = 0.35 + 0.5 * r.nextDouble();
            phase[i] = r.nextDouble() * Fx.TAU;
            color[i] = Fx.mix(pal[r.nextInt(pal.length)], 0xFFFFFF, r.nextDouble() * 0.4);
        }
    }

    @Override public String id() { return "flow"; }
    @Override public String title() { return "Тихий поток: 2000 полосок плывут вокруг невидимой точки в одну сторону"; }
    @Override public int duration() { return 1200; }
    @Override public double distance() { return 70; }

    @Override
    public void tick(ShowContext c, int t) {
        double env = Fx.ramp(t, 0, 150) * (1 - Fx.ramp(t, 1050, 1200));
        int n = (int) (N * env);
        double k = 0.6 + 0.4 * env;
        for (int i = 0; i < n; i++) {
            double breathe = 1 + 0.03 * Math.sin(t * 0.01 + phase[i]);
            Vec3d p = Fx.rot(v0[i], axis[i], omega[i] * t).multiply(radius[i] * k * breathe);
            c.emit(new Spec(Kind.GLOW).pos(c.at(p.x, PY + p.y, p.z)).life(5).size(size[i]).color(color[i])
                    .alpha(alpha[i] * Math.min(1, env * 1.5)).fade(1, 4));
        }
    }
}
