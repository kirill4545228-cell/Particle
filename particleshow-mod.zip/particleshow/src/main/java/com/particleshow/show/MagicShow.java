package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * "THE LAST SPARK" - мини-мультфильм из частиц (100 секунд), с репликами рассказчика над хотбаром.
 * Титры -> маленький маг бредёт ночью -> находит упавшую звезду -> заклинание и магический круг -> звезда оживает птицей света ->
 * приходит Тьма (огромная тень с рогами и щупальцами) -> бой: лучи, щит, пикирование птицы -> птица сливается с посохом, финальный луч ->
 * тень рассыпается -> рассвет и расцветающий луг -> птица улетает в небо и становится созвездием -> THE END.
 */
public final class MagicShow implements Show {
    private static final int END = 2000;
    private static final double SX = 24, SHX = 52, MX = 8;
    private static final double MS = 2.2;
    private static final int[] ORB_T = {1200, 1260, 1320};
    private static final int[] BEAM_T = {1180, 1240, 1300};

    private static final class Fm {
        final Vec3d R, v;
        Fm(Vec3d v) { this.v = v; this.R = new Vec3d(v.z, 0, -v.x); }
        Vec3d loc(double x, double y, double z) { return new Vec3d(R.x * x + v.x * z, y, R.z * x + v.z * z); }
        Vec3d at(ShowContext c, double x, double y, double z) { Vec3d l = loc(x, y, z); return c.at(l.x, l.y, l.z); }
    }

    private final List<double[]> title1 = new ArrayList<>(), title2 = new ArrayList<>();
    private final int FL = 90;
    private final double[] fx = new double[FL], fz = new double[FL], fh = new double[FL];
    private final int[] ftb = new int[FL], fcol = new int[FL];
    private static final double[][] STAR_PTS = {
            {0, 72}, {0, 64}, {0, 55}, {0, 46}, {-11, 68}, {-23, 73}, {-34, 66}, {11, 68}, {23, 73}, {34, 66}};
    private static final int[][] STAR_LINES = {{0, 1}, {1, 2}, {2, 3}, {1, 4}, {4, 5}, {5, 6}, {1, 7}, {7, 8}, {8, 9}};

    public MagicShow() {
        build("THE LAST", 2.3, 88, title1);
        build("SPARK", 2.3, 66, title1);
        build("THE END", 2.3, 76, title2);
        Random r = new Random(21);
        int[] pal = {0xFF8FC8, 0xFFD060, 0x7FB8FF, 0xFFFFFF};
        for (int i = 0; i < FL; i++) {
            fx[i] = (r.nextDouble() * 2 - 1) * 85;
            fz[i] = -25 + r.nextDouble() * 60;
            fh[i] = 6 + r.nextDouble() * 7;
            ftb[i] = 1520 + (int) (Math.hypot(fx[i], fz[i] * 0.5) * 1.4 + r.nextDouble() * 15);
            fcol[i] = pal[r.nextInt(4)];
        }
    }

    @Override public String id() { return "magic"; }
    @Override public String title() { return "THE LAST SPARK - мини-мультфильм про мага, упавшую звезду и Тьму (100 сек, с текстом рассказчика)"; }
    @Override public int duration() { return END; }
    @Override public double distance() { return 70; }

    // ---------- пиксельный шрифт ----------
    private static String[] glyph(char ch) {
        switch (ch) {
            case 'T': return new String[]{"#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#.."};
            case 'H': return new String[]{"#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"};
            case 'E': return new String[]{"#####", "#....", "#....", "####.", "#....", "#....", "#####"};
            case 'L': return new String[]{"#....", "#....", "#....", "#....", "#....", "#....", "#####"};
            case 'A': return new String[]{".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"};
            case 'S': return new String[]{".####", "#....", "#....", ".###.", "....#", "....#", "####."};
            case 'P': return new String[]{"####.", "#...#", "#...#", "####.", "#....", "#....", "#...."};
            case 'R': return new String[]{"####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#"};
            case 'K': return new String[]{"#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#"};
            case 'N': return new String[]{"#...#", "##..#", "##..#", "#.#.#", "#..##", "#..##", "#...#"};
            case 'D': return new String[]{"####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####."};
            default: return null;
        }
    }

    private static void build(String s, double px, double cy, List<double[]> out) {
        double x0 = -(s.length() * 6 - 1) * px / 2;
        for (int ci = 0; ci < s.length(); ci++) {
            String[] g = glyph(s.charAt(ci));
            if (g == null) continue;
            for (int row = 0; row < 7; row++)
                for (int col = 0; col < 5; col++)
                    if (g[row].charAt(col) == '#') out.add(new double[]{x0 + (ci * 6 + col) * px, cy - row * px});
        }
    }

    private void title(ShowContext c, Fm f, int t, int t0, List<double[]> px, int hold, Random r) {
        for (int i = 0; i < px.size(); i++) {
            int d = (i * 37) % 40;
            double[] p = px.get(i);
            if (t == t0 + d) {
                double ox = r.nextGaussian() * 35, oy = Math.abs(r.nextGaussian()) * 25, oz = r.nextGaussian() * 30;
                Vec3d vel = f.loc(-ox / 40.0, -oy / 40.0, -oz / 40.0);
                c.emit(new Spec(Kind.GLOW).pos(f.at(c, p[0] + ox, p[1] + oy, -20 + oz)).vel(vel).life(40).size(0.7)
                        .color(0xFFE9A8).alpha(0.8).fade(5, 0));
            }
            if (t == t0 + d + 40) {
                for (int k = 0; k < 2; k++)
                    c.emit(new Spec(Kind.GLOW).pos(f.at(c, p[0] + r.nextGaussian() * 0.15, p[1] + r.nextGaussian() * 0.15, -20))
                            .life(Math.max(2, hold - d)).size(0.85).color(k == 0 ? 0xFFF2C8 : 0xFFC060).alpha(0.9).fade(3, 40).rise(0.003));
            }
        }
    }

    private void dot(ShowContext c, Fm f, double x, double y, double z, double size, int col, double alpha, int life) {
        c.emit(new Spec(Kind.GLOW).pos(f.at(c, x, y, z)).life(life).size(size).color(col).alpha(alpha).fade(1, Math.max(1, life - 1)));
    }

    // ---------- главный цикл ----------
    @Override
    public void tick(ShowContext c, int t) {
        Random r = c.rng();
        Fm f = new Fm(c.toViewer());
        captions(c, t);
        sky(c, f, t, r);
        if (t >= 10 && t < 190) title(c, f, t, 10, title1, 130, r);
        if (t >= 1850 && t < 1990) title(c, f, t, 1850, title2, 140, r);

        fallingStar(c, f, t, r);
        circle(c, f, t, r);
        if (t >= 200 && t < END - 40) {
            double vis = Fx.ramp(t, 200, 260) * (1 - Fx.ramp(t, 1960, 2000));
            double mx = -70 + (MX + 70) * Fx.ramp(t, 210, 560);
            boolean walking = t > 210 && t < 560;
            double cr = Fx.ramp(t, 590, 620) * (1 - Fx.ramp(t, 700, 730));
            mage(c, f, t, mx, raise(t), cr, orbScale(t), orbColor(t), walking, r, vis);
            if (walking && t % 18 == 0)
                for (int i = 0; i < 6; i++) dot(c, f, mx + r.nextGaussian() * 0.8, 0.2, r.nextGaussian() * 0.8, 0.35, 0xBFD0FF, 0.8, 40);
        }
        thread(c, f, t, r);
        bird(c, f, t, r);
        mist(c, f, t, r);
        shadow(c, f, t, r);
        battle(c, f, t, r);
        dawn(c, f, t, r);
        flowers(c, f, t, r);
        fireflies(c, f, t, r);
        constellation(c, f, t, r);
    }

    private void captions(ShowContext c, int t) {
        switch (t) {
            case 250: c.say("Давным-давно, тёмной ночью, брёл маленький маг…"); break;
            case 420: c.say("Он искал то, что потерял весь мир, - последнюю искру."); break;
            case 600: c.say("И нашёл: упавшую звезду, почти угасшую."); break;
            case 720: c.say("Он вспомнил древнее заклинание…"); break;
            case 790: c.say("И звезда проснулась."); break;
            case 880: c.say("Но свет разбудил Тьму."); break;
            case 1040: c.say("Тень ненавидит всё, что светится."); break;
            case 1190: c.say("Маг и искра сражались вместе."); break;
            case 1390: c.say("Они стали одним целым."); break;
            case 1510: c.say("Тьма рассеялась… и мир расцвёл."); break;
            case 1730: c.say("Пока жива хоть одна искра - жива и магия."); break;
            default: break;
        }
        if (t == 20) c.sound("minecraft:block.beacon.activate", 1f, 0.6f);
        if (t == 230) c.sound("minecraft:entity.firework_rocket.launch", 1f, 0.6f);
        if (t == 760) c.sound("minecraft:block.beacon.power_select", 1f, 0.9f);
        if (t == 880) c.sound("minecraft:entity.warden.emerge", 1f, 0.8f);
        if (t > 880 && t < 1500 && t % 40 == 0) c.sound("minecraft:entity.warden.heartbeat", 0.8f, 0.7f);
        if (t == 1500) c.sound("minecraft:entity.generic.explode", 1f, 0.6f);
        if (t == 1520) c.sound("minecraft:block.amethyst_block.chime", 1f, 0.8f);
        if (t == 1850) c.sound("minecraft:entity.firework_rocket.twinkle_far", 1f, 0.9f);
    }

    // ---------- небо ----------
    private void sky(ShowContext c, Fm f, int t, Random r) {
        double env = Fx.ramp(t, 0, 100) * (1 - Fx.ramp(t, 1950, 2000));
        double dim = 1 - 0.7 * (Fx.ramp(t, 860, 1000) - Fx.ramp(t, 1500, 1560));
        int n = (int) (7 * dim * env + r.nextDouble());
        for (int i = 0; i < n; i++)
            c.emit(new Spec(Kind.STAR).pos(f.at(c, (r.nextDouble() * 2 - 1) * 190, 12 + r.nextDouble() * 140, -110 + r.nextDouble() * 60))
                    .life(160).size(0.35 + 0.35 * r.nextDouble()).color(r.nextInt(3) == 0 ? 0xFFE9A8 : 0xDDEBFF)
                    .alpha(0.8).fade(20, 40).twinkle());
    }

    private void fallingStar(ShowContext c, Fm f, int t, Random r) {
        if (t >= 190 && t < 230) {
            double k = (t - 190) / 40.0;
            double x = Fx.lerp(-40, SX, k), y = Fx.lerp(110, 2, k), z = Fx.lerp(-10, 0, k);
            for (int i = 0; i < 14; i++) {
                double sd = r.nextDouble();
                dot(c, f, x - sd * 9 + r.nextGaussian() * 0.3, y + sd * 6 * 1.2 + r.nextGaussian() * 0.3, z, 0.6, Fx.mix(0xFFFFFF, 0x7FA0FF, sd), 0.8, 14);
            }
            dot(c, f, x, y, z, 1.6, 0xFFFFFF, 1, 2);
        }
        if (t == 230) {
            c.emit(new Spec(Kind.GLOW).pos(f.at(c, SX, 2, 0)).life(10).size(9).color(0xFFFFFF).alpha(0.9).fade(0, 9));
            for (int i = 0; i < 80; i++) {
                double a = r.nextDouble() * Fx.TAU;
                Vec3d vl = f.loc(Math.cos(a) * 0.8, 0.2 + r.nextDouble() * 0.5, Math.sin(a) * 0.8);
                c.emit(new Spec(Kind.EMBER).pos(f.at(c, SX, 2, 0)).vel(vl).gravity(0.02).life(30).size(0.4).color(0xBFD8FF).fade(1, 14));
            }
        }
        if (t >= 230 && t < 760) {
            double b = t < 640 ? 0.35 + 0.15 * Math.sin(t * 0.07) : Fx.lerp(0.4, 1.0, Fx.ramp(t, 640, 760));
            for (int i = 0; i < 40; i++) {
                Vec3d d = Fx.randDir(r);
                dot(c, f, SX + d.x * 2.4, 1.6 + d.y * 1.7, d.z * 2.4, 0.6, Fx.mix(0x7FA0FF, 0xFFFFFF, b - 0.3), 0.4 + 0.5 * b, 3);
            }
            dot(c, f, SX, 1.8, 0, 3 * b + 0.5, 0xBFD8FF, 0.3 * b, 3);
        }
    }

    // ---------- магический круг ----------
    private void circle(ShowContext c, Fm f, int t, Random r) {
        if (t >= 640 && t < 740) {
            double p0 = Fx.ramp(t - 1, 640, 740), p1 = Fx.ramp(t, 640, 740);
            double ds = 0.5 / (Fx.TAU * 15);
            int life = 1500 - t;
            for (int q = (int) Math.floor(p0 / ds) + 1; q <= (int) Math.floor(p1 / ds); q++) {
                double a = q * ds * Fx.TAU;
                c.emit(new Spec(Kind.GLOW).pos(f.at(c, SX + Math.cos(a) * 15, 16 + Math.sin(a) * 15, -4)).life(life).size(0.5).color(0xFFD27A).alpha(0.85).fade(4, 30));
            }
            for (int q = (int) Math.floor(p0 * 12) + 1; q <= (int) Math.floor(p1 * 12); q++) {
                double a = q * Fx.TAU / 12;
                for (int m = 0; m < 4; m++)
                    c.emit(new Spec(Kind.GLOW).pos(f.at(c, SX + Math.cos(a) * (11 + m), 16 + Math.sin(a) * (11 + m), -4)).life(life).size(0.4).color(0x9CC8FF).alpha(0.8).fade(4, 30));
            }
            double ds2 = 0.6 / 24;
            for (int q = (int) Math.floor(p0 / ds2) + 1; q <= (int) Math.floor(p1 / ds2); q++) {
                double s = q * ds2;
                for (int i = 0; i < 6; i++) {
                    double a1 = i * Fx.TAU / 6, a2 = ((i + 2) % 6) * Fx.TAU / 6;
                    c.emit(new Spec(Kind.GLOW).pos(f.at(c, SX + Fx.lerp(Math.cos(a1), Math.cos(a2), s) * 13, 16 + Fx.lerp(Math.sin(a1), Math.sin(a2), s) * 13, -4))
                            .life(life).size(0.4).color(0xC8B4FF).alpha(0.75).fade(4, 30));
                }
            }
        }
        if (t >= 700 && t < 1500) {
            double env = Fx.ramp(t, 700, 760) * (1 - Fx.ramp(t, 1460, 1500));
            for (int i = 0; i < 30; i++) {
                double a = t * 0.04 + i * Fx.TAU / 30;
                dot(c, f, SX + Math.cos(a) * 9, 16 + Math.sin(a) * 9, -4, 0.45, 0xFFE9A8, 0.8 * env, 3);
            }
        }
        if (t == 760) {
            c.emit(new Spec(Kind.GLOW).pos(f.at(c, SX, 3, 0)).life(14).size(14).color(0xFFFFFF).alpha(0.9).fade(1, 12));
            for (int i = 0; i < 300; i++) {
                double a = i * Fx.TAU / 300;
                Vec3d vl = f.loc(Math.cos(a) * 1.3, 0.5 + r.nextDouble() * 0.6, Math.sin(a) * 1.3);
                c.emit(new Spec(Kind.GLOW).pos(f.at(c, SX, 2, 0)).vel(vl).drag(0.95).life(40).size(0.6).color(0xFFE9A8).fade(1, 25));
            }
        }
    }

    // ---------- маг ----------
    private double raise(int t) {
        if (t < 730) return 0;
        if (t < 780) return Fx.ramp(t, 730, 780);
        if (t < 1520) return 1;
        if (t < 1580) return 1 - Fx.ramp(t, 1520, 1580);
        if (t < 1720) return 0;
        if (t < 1800) return 0.55 + 0.45 * Math.sin((t - 1720) * 0.2);
        return 0;
    }

    private double orbScale(int t) {
        if (t < 760) return 0.6;
        if (t < 1380) return 1;
        if (t < 1420) return 1 + 2 * Fx.ramp(t, 1380, 1420);
        if (t < 1500) return 3 + 0.3 * Math.sin(t * 0.5);
        if (t < 1560) return Fx.lerp(3, 0.8, Fx.ramp(t, 1500, 1560));
        return 0.8;
    }

    private int orbColor(int t) {
        if (t < 760) return 0xFFD27A;
        if (t >= 1380 && t < 1500) return 0xFFFFFF;
        return 0xFFE9A8;
    }

    private Vec3d staffTip(double mx, double raise, double cr) {
        return new Vec3d(mx + (2.3 + raise * 0.4) * MS, (8.2 + raise * 0.6) * MS * (1 - 0.18 * cr) + 0.2, 0.5 * MS);
    }

    private void md(ShowContext c, Fm f, double mx, double bob, double cy, double x, double y, double z, double size, int col, double alpha, int life) {
        dot(c, f, mx + x * MS, (y + bob) * MS * cy, z * MS, size * MS * 0.9, col, alpha, life);
    }

    private void mage(ShowContext c, Fm f, int t, double mx, double raise, double cr, double orbS, int orbCol, boolean walking, Random r, double vis) {
        double cy = 1 - 0.18 * cr;
        double bob = walking ? 0.25 * Math.abs(Math.sin(t * 0.35)) : 0.05 * Math.sin(t * 0.1);
        for (int i = 0; i < 70; i++) {
            double y = r.nextDouble() * 5.2, a = r.nextDouble() * Fx.TAU;
            double rad = Fx.lerp(2.4, 0.9, y / 5.2) * (1 + 0.06 * Math.sin(t * 0.2 + y));
            md(c, f, mx, bob, cy, Math.cos(a) * rad, y, Math.sin(a) * rad, 0.4, Fx.mix(0x4B5CFF, 0x9AA8FF, y / 5.2 * 0.6 + r.nextDouble() * 0.3), 0.8 * vis, 3);
        }
        for (int i = 0; i < 8; i++) {
            double a = r.nextDouble() * Fx.TAU;
            md(c, f, mx, bob, cy, Math.cos(a) * 2.4, 0.1, Math.sin(a) * 2.4, 0.3, 0xBFD0FF, 0.8 * vis, 3);
        }
        for (int i = 0; i < 16; i++) {
            Vec3d d = Fx.randDir(r);
            md(c, f, mx, bob, cy, d.x * 0.95, 6.2 + d.y * 0.95, d.z * 0.95, 0.35, 0xFFE4C8, 0.9 * vis, 3);
        }
        for (int i = 0; i < 10; i++)
            md(c, f, mx, bob, cy, 0.5 + r.nextDouble() * 0.5, 4.9 + r.nextDouble() * 0.9, r.nextGaussian() * 0.3, 0.3, 0xFFFFFF, 0.85 * vis, 3);
        for (int i = 0; i < 16; i++) {
            double a = i * Fx.TAU / 16;
            md(c, f, mx, bob, cy, Math.cos(a) * 1.7, 7.0, Math.sin(a) * 1.7, 0.3, 0x6A3CFF, 0.9 * vis, 3);
        }
        for (int i = 0; i < 36; i++) {
            double y = 7 + r.nextDouble() * 3.6, a = r.nextDouble() * Fx.TAU, k = (y - 7) / 3.6;
            md(c, f, mx, bob, cy, Math.cos(a) * 1.3 * (1 - k) - k * 0.9, y, Math.sin(a) * 1.3 * (1 - k), 0.35, Fx.mix(0x7A4CFF, 0xC0A0FF, k), 0.9 * vis, 3);
        }
        if (r.nextInt(3) == 0) md(c, f, mx, bob, cy, 0.9, 8.2, 1.0, 0.25, 0xFFFFFF, vis, 6);
        double hx = 2.1, hy = 3.4 + raise * 3.4;
        for (int i = 0; i <= 10; i++) {
            double k = i / 10.0;
            md(c, f, mx, bob, cy, Fx.lerp(0.6, hx, k), Fx.lerp(4.7, hy, k), 0.5, 0.3, 0x6B7CFF, 0.9 * vis, 3);
        }
        double sx2 = 2.3 + raise * 0.4, sy2 = 8.2 + raise * 0.6;
        for (int i = 0; i <= 18; i++) {
            double k = i / 18.0;
            md(c, f, mx, bob, cy, Fx.lerp(2.1, sx2, k), sy2 * k, 0.5, 0.25, 0xC89A5A, 0.9 * vis, 3);
        }
        double pulse = 1 + 0.2 * Math.sin(t * 0.25);
        md(c, f, mx, bob, cy, sx2, sy2 + 0.3, 0.5, 0.8 * orbS * pulse, orbCol, vis, 3);
        md(c, f, mx, bob, cy, sx2, sy2 + 0.3, 0.5, 1.8 * orbS * pulse, orbCol, 0.25 * vis, 3);
        c.emit(new Spec(Kind.STAR).pos(f.at(c, mx + sx2 * MS, (sy2 + 0.3 + bob) * MS * cy, 0.5 * MS)).life(3).size(2.0 * orbS * MS * 0.7).color(orbCol).alpha(0.6 * vis).fade(1, 2));
        for (int i = 0; i < 10; i++)
            c.emit(new Spec(Kind.GLOW).pos(f.at(c, mx - (1.2 + r.nextDouble() * 1.5) * MS, (3 + r.nextDouble() * 2) * MS * cy, r.nextGaussian() * 0.9))
                    .vel(f.loc(-0.08, 0, 0)).life(6).size(0.4).color(0x7A8CFF).alpha(0.5 * vis).fade(1, 4));
        if (orbS > 0.9 && r.nextInt(2) == 0)
            c.emit(new Spec(Kind.STAR).pos(f.at(c, mx + sx2 * MS + r.nextGaussian() * 2, (sy2 + 0.3) * MS * cy + r.nextGaussian() * 2, 0.5 * MS))
                    .vel(0, 0.05, 0).life(20).size(0.5).color(orbCol).fade(2, 12).twinkle());
    }

    private void beam(ShowContext c, Fm f, Vec3d from, Vec3d to, int t, double thick, int strands, int samples) {
        Vec3d d = to.subtract(from);
        Vec3d dir = d.normalize();
        Vec3d n1 = Fx.perp(dir), n2 = dir.crossProduct(n1);
        for (int i = 0; i <= samples; i++) {
            double s = i / (double) samples;
            Vec3d p = from.add(d.multiply(s));
            double w = thick * (0.4 + 0.6 * Math.sin(Math.PI * Math.min(1, s * 1.2 + 0.1)));
            for (int k = 0; k < strands; k++) {
                double a = s * 22 - t * 0.9 + k * Fx.TAU / strands;
                Vec3d o = n1.multiply(Math.cos(a) * w).add(n2.multiply(Math.sin(a) * w));
                dot(c, f, p.x + o.x, p.y + o.y, p.z + o.z, 0.6, Fx.mix(0xFFE9A8, 0xFFFFFF, (k + 1.0) / strands), 0.85, 3);
            }
            dot(c, f, p.x, p.y, p.z, 0.5 + thick * 0.15, 0xFFFFFF, 0.9, 3);
        }
    }

    private void thread(ShowContext c, Fm f, int t, Random r) {
        if (t >= 770 && t < 860) {
            Vec3d tip = staffTip(MX, 1, 0);
            // нить света от посоха к звезде/птице у земли
            Vec3d to = new Vec3d(SX, 3 + Fx.ramp(t, 770, 860) * 10, 0);
            beam(c, f, tip, to, t, 0.4, 2, 40);
        }
    }

    // ---------- птица света ----------
    private Vec3d orbit(int t) {
        double a = t * 0.045;
        return new Vec3d(MX + 16 * Math.cos(a), 14 + 3 * Math.sin(t * 0.03), 13 * Math.sin(a));
    }

    private Vec3d birdPos(int t) {
        if (t < 760) return null;
        if (t < 860) {
            double k = Fx.smooth(Fx.ramp(t, 760, 860));
            Vec3d p = Fx.lerp(new Vec3d(SX, 3, 0), orbit(t), k);
            return p.add(0, 12 * Math.sin(Math.PI * k), 0);
        }
        if (t < 1160) return orbit(t);
        if (t < 1380) {
            double phase = (t - 1160) % 90;
            double b = Math.pow(Math.sin(Math.PI * phase / 90.0), 1.5);
            return Fx.lerp(orbit(t), new Vec3d(SHX - 12, 20, 0), b);
        }
        if (t < 1420) return Fx.lerp(orbit(t), staffTip(MX, 1, 0), Fx.smooth(Fx.ramp(t, 1380, 1420)));
        if (t >= 1700 && t < 1850) {
            double e = Fx.smooth(Fx.ramp(t, 1700, 1850));
            Vec3d a = staffTip(MX, 0, 0), b = new Vec3d(0, 72, -30);
            return Fx.lerp(a, b, e).add(8 * Math.cos(e * 20) * (1 - e), 0, 8 * Math.sin(e * 20) * (1 - e));
        }
        return null;
    }

    private void bird(ShowContext c, Fm f, int t, Random r) {
        if (t >= 1160 && t < 1380 && (t - 1160) % 90 == 45) {
            Vec3d tg = new Vec3d(SHX - 12, 20, 0);
            c.emit(new Spec(Kind.GLOW).pos(f.at(c, tg.x, tg.y, tg.z)).life(12).size(9).color(0xFFFFFF).alpha(0.9).fade(0, 10));
            for (int i = 0; i < 80; i++) {
                Vec3d d = Fx.randDir(r).multiply(0.6 + r.nextDouble() * 0.8);
                c.emit(new Spec(Kind.GLOW).pos(f.at(c, tg.x, tg.y, tg.z)).vel(d).drag(0.94).life(30).size(0.5)
                        .color(i % 2 == 0 ? 0xFFE9A8 : 0xB04CFF).fade(1, 18));
            }
            c.sound("minecraft:entity.firework_rocket.blast_far", 0.8f, 1f);
        }
        if (t == 1420) {
            Vec3d tp = staffTip(MX, 1, 0);
            c.emit(new Spec(Kind.GLOW).pos(f.at(c, tp.x, tp.y, tp.z)).life(16).size(16).color(0xFFFFFF).alpha(0.9).fade(1, 14));
            c.sound("minecraft:entity.generic.explode", 0.8f, 1.3f);
        }
        if (t == 1850) {
            c.emit(new Spec(Kind.GLOW).pos(f.at(c, 0, 72, -30)).life(16).size(14).color(0xFFFFFF).alpha(0.9).fade(1, 14));
        }
        Vec3d ps = birdPos(t), pn = birdPos(t + 1);
        if (ps == null || pn == null) return;
        Vec3d P = f.loc(ps.x, ps.y, ps.z), Pn = f.loc(pn.x, pn.y, pn.z);
        Vec3d vel = Pn.subtract(P);
        Vec3d fw = vel.normalize();
        Vec3d rt = fw.crossProduct(new Vec3d(0, 1, 0)).normalize();
        Vec3d u = rt.crossProduct(fw).normalize();
        double phi = 0.7 * Math.sin(t * 0.26) + 0.1;
        for (double s = -2; s <= 2; s += 0.5) {
            Vec3d q = P.add(fw.multiply(s));
            c.emit(new Spec(Kind.GLOW).pos(c.at(q.x, q.y, q.z)).vel(vel).life(3).size(0.6).color(0xFFF0C0).fade(1, 2));
        }
        c.emit(new Spec(Kind.GLOW).pos(c.at(P.x, P.y, P.z)).life(3).size(2.2).color(0xFFE9A8).alpha(0.35).fade(1, 2));
        for (int sg = -1; sg <= 1; sg += 2) {
            for (int k = 0; k < 10; k++) {
                double beta = -0.2 + k * 0.1, len = 4.5 + 12 * Math.sin(Math.PI * (k + 1) / 11.0);
                Vec3d d0 = rt.multiply(sg * Math.cos(beta)).subtract(fw.multiply(Math.sin(beta)));
                Vec3d d = Fx.rot(d0, fw, -sg * phi);
                for (double s = 0.5; s < len; s += 0.9) {
                    double x = s / len;
                    Vec3d pos = P.add(d.multiply(s)).subtract(u.multiply(0.02 * s * s));
                    c.emit(new Spec(Kind.GLOW).pos(c.at(pos.x, pos.y, pos.z)).vel(vel).life(3).size(0.6)
                            .color(Fx.mix(0xFFFFFF, 0x8AD0FF, x)).alpha(0.85 - 0.35 * x).fade(1, 2));
                }
            }
        }
        for (int i = 0; i < 12; i++)
            c.emit(new Spec(Kind.STAR).pos(c.at(P.x + r.nextGaussian() * 0.6, P.y + r.nextGaussian() * 0.6, P.z + r.nextGaussian() * 0.6))
                    .vel(r.nextGaussian() * 0.02, -0.02, r.nextGaussian() * 0.02).life(35).size(0.4).color(0xFFE9A8).fade(2, 20).twinkle());
    }

    // ---------- Тьма ----------
    private void mist(ShowContext c, Fm f, int t, Random r) {
        if (t < 860 || t > 1500) return;
        double env = Fx.ramp(t, 860, 940) * (1 - Fx.ramp(t, 1440, 1500));
        int n = (int) (8 * env);
        for (int i = 0; i < n; i++)
            c.emit(new Spec(Kind.GLOW).pos(f.at(c, 20 + r.nextDouble() * 70, 0.5 + r.nextDouble() * 14, r.nextGaussian() * 15))
                    .vel(f.loc(-0.05, 0, 0)).life(60).size(5).color(0x5A2AA0).alpha(0.07).fade(15, 25));
    }

    private void shadow(ShowContext c, Fm f, int t, Random r) {
        double rise = Fx.smooth(Fx.ramp(t, 860, 1000));
        if (rise <= 0 || t >= 1500) return;
        double sx = SHX + (t >= 1420 ? 0.5 * Math.sin(t * 1.3) : 0);
        int n = (int) (130 * rise);
        for (int i = 0; i < n; i++) {
            Vec3d d = Fx.randDir(r);
            double rr = Math.sqrt(r.nextDouble());
            dot(c, f, sx + d.x * 13 * rr, (16 + d.y * 17 * rr) * rise, d.z * 9 * rr, 1.5, Fx.mix(0x3A1070, 0x9A3CFF, r.nextDouble()), 0.45, 5);
        }
        for (int i = 0; i < 12; i++)
            c.emit(new Spec(Kind.GLOW).pos(f.at(c, sx + r.nextGaussian() * 8, 30 * rise, r.nextGaussian() * 5)).vel(0, 0.15, 0)
                    .life(30).size(2.2).color(0x6A2AC0).alpha(0.2).fade(4, 20));
        if (rise > 0.7) {
            for (int sd = -1; sd <= 1; sd += 2) {
                dot(c, f, sx - 11, 27 * rise, sd * 3, 1.6, 0xFF3A2A, 1, 3);
                dot(c, f, sx - 11, 27 * rise, sd * 3, 3.2, 0xFF3A2A, 0.35, 3);
                dot(c, f, sx - 11.4, 27 * rise, sd * 3, 0.7, 0xFFE070, 1, 3);
                for (int i = 0; i <= 14; i++) {
                    double s = i / 14.0;
                    dot(c, f, sx - 3 - 3 * s, 30 * rise + 17 * s - 4 * s * s, sd * (4 + 6 * s), 0.8 * (1 - 0.5 * s), 0xB04CFF, 0.9, 3);
                }
            }
        }
        for (int k = 0; k < 6; k++) {
            double zk = -10 + 4 * k;
            double reach = 0.5 + 0.5 * Math.sin(t * 0.04 + k * 1.1);
            Vec3d B = new Vec3d(sx - 4, 5, zk);
            Vec3d C = new Vec3d(sx - 18, 20 + 6 * Math.sin(t * 0.05 + k), zk);
            Vec3d T = new Vec3d(sx - 4 - 30 * reach - 6, 1 + 14 * (1 - reach), zk * 0.8 + 4 * Math.sin(t * 0.07 + k));
            for (int i = 0; i <= 28; i++) {
                double s = i / 28.0, a = (1 - s) * (1 - s), b = 2 * s * (1 - s), cc = s * s;
                dot(c, f, a * B.x + b * C.x + cc * T.x, (a * B.y + b * C.y + cc * T.y) * rise, a * B.z + b * C.z + cc * T.z,
                        0.9 * (1 - s) + 0.35, Fx.mix(0x5A1FA0, 0xB04CFF, s), 0.7, 3);
            }
            if (t >= 1160 && t < 1500 && t % 110 == 60 && k == (t / 110) % 6) {
                Vec3d g = f.at(c, T.x, 0.4, T.z);
                Fx.shock(c, g, 1.1, 50, 0xA040FF, 24, 0.55);
                c.sound("minecraft:entity.generic.explode", 0.5f, 0.5f);
            }
        }
    }

    private void battle(ShowContext c, Fm f, int t, Random r) {
        Vec3d tip = staffTip(MX, 1, 0);
        for (int e : BEAM_T)
            if (t >= e && t < e + 14) {
                Vec3d chest = new Vec3d(SHX - 10, 20, 0);
                beam(c, f, tip, chest, t, 1.2, 3, 70);
                for (int i = 0; i < 12; i++) {
                    Vec3d d = Fx.randDir(r).multiply(0.5);
                    c.emit(new Spec(Kind.GLOW).pos(f.at(c, chest.x, chest.y, chest.z)).vel(d).drag(0.95).life(20).size(0.5)
                            .color(i % 2 == 0 ? 0xFFE9A8 : 0xB04CFF).fade(1, 12));
                }
                if (t == e) c.sound("minecraft:entity.evoker.cast_spell", 1f, 1.2f);
            }
        for (int e : ORB_T) {
            if (t >= e && t < e + 40) {
                double k = (t - e) / 40.0;
                double x = Fx.lerp(SHX - 12, MX + 2, k), y = Fx.lerp(22, 6, k);
                for (int i = 0; i < 25; i++) {
                    Vec3d d = Fx.randDir(r).multiply(2);
                    dot(c, f, x + d.x, y + d.y, d.z, 0.7, Fx.mix(0x5A1FA0, 0xC070FF, r.nextDouble()), 0.8, 3);
                }
                dot(c, f, x, y, 0, 2.0, 0xFF3A2A, 0.6, 3);
            }
            if (t >= e + 40 && t < e + 52) {
                double k = (t - e - 40) / 12.0;
                for (int i = 0; i < 60; i++) {
                    Vec3d d = Fx.randDir(r);
                    double dy = Math.abs(d.y);
                    dot(c, f, MX + 1 + d.x * 10, 5 + dy * 10, d.z * 10, 0.9, 0xFFE9A8, 0.8 * (1 - k), 3);
                }
                if (t == e + 40) {
                    c.sound("minecraft:item.shield.block", 1f, 0.8f);
                    for (int i = 0; i < 40; i++)
                        c.emit(new Spec(Kind.STAR).pos(f.at(c, MX + 6, 6, 0)).vel(f.loc(r.nextGaussian() * 0.4, r.nextDouble() * 0.5, r.nextGaussian() * 0.4))
                                .gravity(0.02).life(25).size(0.5).color(0xFFE9A8).fade(1, 14));
                }
            }
        }
        if (t >= 1420 && t < 1500) {
            double k = Fx.ramp(t, 1420, 1500);
            Vec3d chest = new Vec3d(SHX - 8, 22, 0);
            beam(c, f, tip, chest, t, 1 + 3 * k, 4, 90);
            if (t % 4 == 0) {
                double s = (t * 0.07) % 1;
                Vec3d p = Fx.lerp(tip, chest, s);
                c.emit(new Spec(Kind.RING).pos(f.at(c, p.x, p.y, p.z)).life(14).size(1 + 2 * k).grow(0.1).color(0xFFE9A8).alpha(0.7).fade(1, 10));
            }
            for (int i = 0; i < 20; i++) {
                Vec3d d = Fx.randDir(r).multiply(0.4 + r.nextDouble() * 0.9);
                c.emit(new Spec(Kind.GLOW).pos(f.at(c, chest.x, chest.y, chest.z)).vel(d).drag(0.95).life(24).size(0.5)
                        .color(i % 2 == 0 ? 0xFFFFFF : 0xB04CFF).fade(1, 14));
            }
        }
        if (t == 1500) {
            c.emit(new Spec(Kind.GLOW).pos(f.at(c, SHX, 20, 0)).life(20).size(30).color(0xFFFFFF).alpha(0.95).fade(1, 18));
            for (int i = 0; i < 1100; i++) {
                Vec3d d = Fx.randDir(r);
                double rr = Math.sqrt(r.nextDouble());
                Vec3d vl = f.loc(d.x * (0.8 + r.nextDouble()), Math.abs(d.y) * 0.9 + 0.1, d.z * (0.8 + r.nextDouble()));
                c.emit(new Spec(Kind.GLOW).pos(f.at(c, SHX + d.x * 13 * rr, (16 + d.y * 17 * rr), d.z * 9 * rr)).vel(vl).drag(0.96).life(46).size(0.7)
                        .color(Fx.mix(0x5A1FA0, 0xFFD060, r.nextDouble())).fade(1, 26));
            }
            Fx.shock(c, f.at(c, SHX, 0.5, 0), 3.0, 260, 0xFFE9A8, 50, 0.8);
        }
        if (t == 1540) {
            for (int i = 0; i < 600; i++)
                c.emit(new Spec(Kind.STAR).pos(f.at(c, SHX + r.nextGaussian() * 14, r.nextDouble() * 30, r.nextGaussian() * 9))
                        .vel(f.loc(r.nextGaussian() * 0.05 - 0.02, 0.05 + r.nextDouble() * 0.08, r.nextGaussian() * 0.04))
                        .life(220).size(0.4).color(r.nextInt(2) == 0 ? 0xFFE9A8 : 0xFFB0D8).fade(10, 80).twinkle());
        }
    }

    // ---------- рассвет, цветы, светлячки ----------
    private void dawn(ShowContext c, Fm f, int t, Random r) {
        if (t < 1500 || t >= END - 60) return;
        double env = Fx.ramp(t, 1500, 1600) * (1 - Fx.ramp(t, 1900, 1990));
        int n = (int) (8 * env + r.nextDouble());
        for (int i = 0; i < n; i++)
            c.emit(new Spec(Kind.GLOW).pos(f.at(c, (r.nextDouble() * 2 - 1) * 100, 2 + r.nextDouble() * 30, -60 + r.nextDouble() * 6))
                    .life(80).size(9).color(Fx.mix(0xFF9A50, 0xFF5A8A, r.nextDouble())).alpha(0.05).fade(20, 40));
        if (t % 20 == 0)
            c.emit(new Spec(Kind.GLOW).pos(f.at(c, 0, 6, -60)).life(40).size(18).color(0xFFD090).alpha(0.14 * env).fade(10, 20));
    }

    private void flowers(ShowContext c, Fm f, int t, Random r) {
        if (t < 1520 || t > 1800) return;
        for (int i = 0; i < FL; i++) {
            int tb = ftb[i];
            if (t > tb + 31) continue;
            if (t >= tb && t < tb + 30) {
                double p0 = Fx.ramp(t - 1, tb, tb + 30), p1 = Fx.ramp(t, tb, tb + 30);
                double ds = 0.5 / fh[i];
                for (int q = (int) Math.floor(p0 / ds) + 1; q <= (int) Math.floor(p1 / ds); q++)
                    c.emit(new Spec(Kind.GLOW).pos(f.at(c, fx[i], q * ds * fh[i], fz[i])).life(END - t).size(0.4).color(0x5AF0A0).alpha(0.8).fade(3, 60));
            }
            if (t == tb + 30) {
                double h = fh[i];
                for (int pet = 0; pet < 6; pet++) {
                    double a = pet * Fx.TAU / 6;
                    for (int m = 1; m <= 3; m++)
                        c.emit(new Spec(Kind.GLOW).pos(f.at(c, fx[i] + Math.cos(a) * m * 0.8, h + Math.sin(a) * m * 0.7, fz[i] + Math.sin(a) * m * 0.3))
                                .life(END - t).size(0.5).color(fcol[i]).alpha(0.9).fade(3, 60));
                }
                c.emit(new Spec(Kind.GLOW).pos(f.at(c, fx[i], h, fz[i])).life(END - t).size(1.2).color(0xFFFFFF).fade(3, 60));
                c.emit(new Spec(Kind.GLOW).pos(f.at(c, fx[i], h, fz[i])).life(END - t).size(3.2).color(fcol[i]).alpha(0.2).fade(10, 60));
            }
        }
    }

    private void fireflies(ShowContext c, Fm f, int t, Random r) {
        if (t < 1500 || t >= END - 100) return;
        for (int i = 0; i < 10; i++)
            c.emit(new Spec(Kind.STAR).pos(f.at(c, (r.nextDouble() * 2 - 1) * 90, r.nextDouble() * 20, -25 + r.nextDouble() * 55))
                    .vel(f.loc(r.nextGaussian() * 0.02, 0.02 + r.nextDouble() * 0.03, r.nextGaussian() * 0.02))
                    .life(120).size(0.3).color(0xFFF0A0).fade(15, 40).twinkle());
    }

    // ---------- созвездие ----------
    private void constellation(ShowContext c, Fm f, int t, Random r) {
        if (t < 1780 || t > 1990) return;
        for (int i = 0; i < STAR_PTS.length; i++) {
            if (t == 1780 + i * 6)
                c.emit(new Spec(Kind.STAR).pos(f.at(c, STAR_PTS[i][0], STAR_PTS[i][1], -30)).life(END - t).size(2.2).color(0xFFF0C8).fade(5, 60).twinkle());
        }
        for (int j = 0; j < STAR_LINES.length; j++) {
            int t0 = 1800 + j * 10;
            if (t < t0 || t >= t0 + 10) continue;
            double[] a = STAR_PTS[STAR_LINES[j][0]], b = STAR_PTS[STAR_LINES[j][1]];
            double len = Math.hypot(b[0] - a[0], b[1] - a[1]);
            double p0 = Fx.ramp(t - 1, t0, t0 + 10), p1 = Fx.ramp(t, t0, t0 + 10);
            double ds = 0.8 / len;
            for (int q = (int) Math.floor(p0 / ds) + 1; q <= (int) Math.floor(p1 / ds); q++) {
                double s = q * ds;
                c.emit(new Spec(Kind.GLOW).pos(f.at(c, Fx.lerp(a[0], b[0], s), Fx.lerp(a[1], b[1], s), -30)).life(END - t).size(0.4)
                        .color(0xBFD8FF).alpha(0.55).fade(4, 60));
            }
        }
    }
}
