package com.particleshow.show;

import net.minecraft.util.math.Vec3d;

/** Быстрая проверка, что частицы вообще рисуются: яркое кольцо и столб света в 12 блоках перед тобой (10 секунд). */
public final class TestShow implements Show {
    @Override public String id() { return "test"; }
    @Override public String title() { return "Проверка: яркое кольцо и столб света прямо перед тобой"; }
    @Override public int duration() { return 200; }
    @Override public double distance() { return 12; }

    @Override
    public void tick(ShowContext c, int t) {
        Vec3d v = c.toViewer();
        Vec3d rt = new Vec3d(-v.z, 0, v.x);
        for (int i = 0; i < 90; i++) {
            double a = i * Fx.TAU / 90 + t * 0.05;
            c.emit(new Spec(Kind.GLOW).pos(c.at(rt.x * Math.cos(a) * 5, 6 + Math.sin(a) * 5, rt.z * Math.cos(a) * 5))
                    .life(4).size(0.5).color(Fx.hsv(i / 90.0 + t * 0.01, 0.6, 1)).fade(1, 2));
        }
        for (int i = 0; i < 20; i++)
            c.emit(new Spec(Kind.STAR).pos(c.at(0, i * 0.8, 0)).life(4).size(0.6).color(0xFFE9A8).fade(1, 2));
    }
}
