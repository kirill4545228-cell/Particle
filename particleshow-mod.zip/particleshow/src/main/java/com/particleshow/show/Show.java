package com.particleshow.show;

public interface Show {
    String id();
    String title();
    /** Длительность в тиках (20 тиков = 1 сек). */
    int duration();
    /** На каком расстоянии перед игроком (в блоках при масштабе 1) ставить центр шоу. */
    double distance();
    void tick(ShowContext c, int t);
}
