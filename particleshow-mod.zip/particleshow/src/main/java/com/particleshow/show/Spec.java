package com.particleshow.show;

import net.minecraft.util.math.Vec3d;

/** Описание одной частицы. Позиция абсолютная, скорость/гравитация/рост - в "локальных" единицах (умножаются на масштаб шоу). */
public final class Spec {
    public Kind kind;
    public double x, y, z, vx, vy, vz;
    public int life = 20, rgb = 0xFFFFFF, fadeIn = 2, fadeOut = -1;
    public float size = 0.4f, alpha = 1f, drag = 1f, gravity = 0f, rise = 0f, grow = 0f;
    public boolean additive = true, twinkle = false;

    public Spec(Kind k) { this.kind = k; }

    public Spec pos(Vec3d v) { x = v.x; y = v.y; z = v.z; return this; }
    public Spec pos(double px, double py, double pz) { x = px; y = py; z = pz; return this; }
    public Spec vel(Vec3d v) { vx = v.x; vy = v.y; vz = v.z; return this; }
    public Spec vel(double a, double b, double c) { vx = a; vy = b; vz = c; return this; }
    public Spec life(int l) { life = Math.max(1, l); return this; }
    public Spec size(double s) { size = (float) s; return this; }
    public Spec color(int c) { rgb = c; return this; }
    public Spec alpha(double a) { alpha = (float) a; return this; }
    public Spec drag(double d) { drag = (float) d; return this; }
    public Spec gravity(double g) { gravity = (float) g; return this; }
    public Spec rise(double r) { rise = (float) r; return this; }
    public Spec grow(double g) { grow = (float) g; return this; }
    public Spec fade(int in, int out) { fadeIn = in; fadeOut = out; return this; }
    public Spec twinkle() { twinkle = true; return this; }
    public Spec solid() { additive = false; return this; }
}
