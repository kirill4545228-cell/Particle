package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.Random;

/** Гигантская двойная спираль ДНК (92 блока), вращается, растёт вверх, по ней бегут фотоны. */
public final class DnaShow implements Show {
    private static final int[] BASE = {0xFFD23F, 0x3BCEAC, 0xEE4266, 0x8E7DFF};

    @Override public String id() { return "dna"; }
    @Override public String title() { return "Двойная спираль ДНК высотой 92 блока"; }
    @Override public int duration() { return 640; }
    @Override public double distance() { return 45; }

    @Override
    public void tick(ShowContext c, int t) {
        Random r = c.rng();
        if (t == 0) c.sound("minecraft:block.beacon.power_select", 1f, 0.7f);
        double grow = Fx.smooth(t / 120.0) * (1 - Fx.smooth((t - 540) / 100.0));
        if (t == 560) {
            c.emit(new Spec(Kind.GLOW).pos(c.at(0, 46, 0)).life(14).size(18).color(0xFFFFFF).alpha(0.8).fade(1, 12));
            c.sound("minecraft:entity.firework_rocket.twinkle_far", 1f, 0.8f);
        }
        double H = 92 * grow;
        if (H < 1) return;
        double rot = t * 0.045;
        int n = 260;
        for (int j = 0; j < n; j++) {
            double y = H * (j + r.nextDouble()) / n;
            double a = y * 0.16 + rot, rad = 8 + 1.2 * Math.sin(y * 0.1 - t * 0.03);
            double x1 = Math.cos(a) * rad, z1 = Math.sin(a) * rad;
            c.emit(new Spec(Kind.GLOW).pos(c.at(x1, y, z1)).life(3).size(0.55).color(0x3DE8FF).alpha(0.9).fade(1, 2));
            c.emit(new Spec(Kind.GLOW).pos(c.at(-x1, y, -z1)).life(3).size(0.55).color(0xFF4FD8).alpha(0.9).fade(1, 2));
        }
        int k = 0;
        for (double y = 1.5; y < H; y += 2.2, k++) {
            double a = y * 0.16 + rot, rad = 8 + 1.2 * Math.sin(y * 0.1 - t * 0.03);
            double x1 = Math.cos(a) * rad, z1 = Math.sin(a) * rad;
            int ca = BASE[k % 4], cb = BASE[3 - k % 4];
            for (int m = 1; m < 9; m++) {
                double f = m / 9.0;
                c.emit(new Spec(Kind.GLOW).pos(c.at(Fx.lerp(x1, -x1, f), y, Fx.lerp(z1, -z1, f))).life(2).size(0.32)
                        .color(f < 0.5 ? ca : cb).alpha(0.7).fade(0, 1));
            }
            c.emit(new Spec(Kind.GLOW).pos(c.at(x1, y, z1)).life(3).size(0.9).color(ca).fade(1, 2));
            c.emit(new Spec(Kind.GLOW).pos(c.at(-x1, y, -z1)).life(3).size(0.9).color(cb).fade(1, 2));
        }
        double yp = (t * 1.1) % H;
        double ap = yp * 0.16 + rot, rp = 8 + 1.2 * Math.sin(yp * 0.1 - t * 0.03);
        c.emit(new Spec(Kind.GLOW).pos(c.at(Math.cos(ap) * rp, yp, Math.sin(ap) * rp)).life(3).size(2).color(0xFFFFFF).fade(0, 2));
        c.emit(new Spec(Kind.GLOW).pos(c.at(-Math.cos(ap) * rp, yp, -Math.sin(ap) * rp)).life(3).size(2).color(0xFFFFFF).fade(0, 2));
        for (int i = 0; i < 10; i++) {
            double y = r.nextDouble() * H, a = y * 0.16 + rot, rad = 8 + r.nextDouble() * 3;
            c.emit(new Spec(Kind.SPARK).pos(c.at(Math.cos(a) * rad, y, Math.sin(a) * rad)).vel(0, 0.15 + r.nextDouble() * 0.1, 0)
                    .life(30).size(0.35).color(0xBFF6FF).fade(2, 15).twinkle());
        }
        c.emit(new Spec(Kind.STAR).pos(c.at(0, H, 0)).life(3).size(2.5).color(0xFFFFFF).fade(0, 2));
        if (t % 40 == 0)
            c.emit(new Spec(Kind.RING).pos(c.at(0, 0.6, 0)).life(40).size(1).grow(0.6).color(0x3DE8FF).alpha(0.7).fade(2, 30));
    }
}
